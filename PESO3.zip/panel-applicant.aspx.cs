﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class panel_applicant : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected int widesData;
        protected void Page_Load(object sender, EventArgs e)
        {
            reserve();
            lblid.Text = "" + Session["applicant_number"];

            tbfname.Text = "" + Session["fname"];
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            update();
            Calendar2.Visible = false;
            ddyear.Visible = false;
            ddmonth.Visible = false;
            lblyear.Visible = false;
            lblmonth.Visible = false;



            DataSet years = new DataSet();
            years.ReadXml(Server.MapPath("~/Year.xml"));

            ddyear.DataTextField = "Number";
            ddyear.DataTextField = "Number";

            ddyear.DataSource = years;
            ddyear.DataBind();

            DataSet months = new DataSet();
            months.ReadXml(Server.MapPath("~/Month.xml"));

            ddmonth.DataTextField = "Name";
            ddmonth.DataTextField = "Number";

            ddmonth.DataSource = months;
            ddmonth.DataBind();



           
        }
        public void enable()
        {
            tbfname.Enabled = true;
            tbmname.Enabled = true;
            tblname.Enabled = true;

            ddtime.Enabled = true;

        }
        public void disable()
        {
            tbfname.Enabled = false;
            tbmname.Enabled = false;
            tblname.Enabled = false;
            btnSave.Enabled = false;
            btnCancel.Enabled = false;
            ddtime.Enabled = false;

        }
        public void clear()
        {
            lblid.Text = "";
            tbfname.Text = "";
            tbmname.Text = "";
            tblname.Text = "";
            
            ddtime.Text = "Select Time";
            lblemail.Text = "";
        }
        public void update()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {

                string query = "UPDATE tb_onlineapplicant SET  fname = @fname where applicant_number = @applicant_number ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@applicant_number", lblid.Text);
                cmd.Parameters.AddWithValue("@fname", tbmname.Text);
               

                cmd.Connection.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    gvReserve.DataBind();
                   
                    clear();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);

                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
        /*    disable();
            clear();
            EditButton.Enabled = false;
            DeleteButton.Enabled = false;
           */
            tbfname.Text = tbmname.Text.Trim();
        }

        protected void gvReserve_SelectedIndexChanged1(object sender, EventArgs e)
        {
            GridViewRow gr2 = gvReserve.SelectedRow;
            lblid.Text = gr2.Cells[1].Text;
            tbfname.Text = gr2.Cells[2].Text;
            tbmname.Text = gr2.Cells[3].Text;
            tblname.Text = gr2.Cells[4].Text;
            lblemail.Text = gr2.Cells[5].Text;

            EditButton.Enabled = true;
            DeleteButton.Enabled = true;
            btnSave.Enabled = true;
            btnCancel.Enabled = true;
        }

        protected void gvReserve_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        // Row
                        gvReserve.Columns[0].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[1].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[2].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[3].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[4].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[5].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[6].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[7].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[8].ItemStyle.Width = widesData * 50;





                        gvReserve.Columns[0].ItemStyle.Wrap = false;
                        gvReserve.Columns[1].ItemStyle.Wrap = false;
                        gvReserve.Columns[2].ItemStyle.Wrap = false;
                        gvReserve.Columns[3].ItemStyle.Wrap = false;
                        gvReserve.Columns[4].ItemStyle.Wrap = false;
                        gvReserve.Columns[5].ItemStyle.Wrap = false;
                        gvReserve.Columns[6].ItemStyle.Wrap = false;
                        gvReserve.Columns[7].ItemStyle.Wrap = false;
                        gvReserve.Columns[8].ItemStyle.Wrap = false;






                        //head

                        gvReserve.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[8].HeaderStyle.Width = widesData * 50;





                        gvReserve.Columns[0].HeaderStyle.Wrap = false;
                        gvReserve.Columns[1].HeaderStyle.Wrap = false;
                        gvReserve.Columns[2].HeaderStyle.Wrap = false;
                        gvReserve.Columns[3].HeaderStyle.Wrap = false;
                        gvReserve.Columns[4].HeaderStyle.Wrap = false;
                        gvReserve.Columns[5].HeaderStyle.Wrap = false;
                        gvReserve.Columns[6].HeaderStyle.Wrap = false;
                        gvReserve.Columns[7].HeaderStyle.Wrap = false;
                        gvReserve.Columns[8].HeaderStyle.Wrap = false;




                    }

                }
            }
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
                ddyear.Visible = false;
                ddmonth.Visible = false;
                lblyear.Visible = false;
                lblmonth.Visible = false;

                tbDate.Text = "";
            }
            else
            {
                Calendar2.Visible = true;
                ddyear.Visible = true;
                ddmonth.Visible = true;
                lblyear.Visible = true;
                lblmonth.Visible = true;
            }
        }

        protected void ddyear_SelectedIndexChanged1(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar2.VisibleDate = new DateTime(year, month, 1);
            Calendar2.SelectedDate = new DateTime(year, month, 1);
        }

        protected void ddmonth_SelectedIndexChanged1(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar2.VisibleDate = new DateTime(year, month, 1);
            Calendar2.SelectedDate = new DateTime(year, month, 1);
        }

        protected void Calendar2_SelectionChanged1(object sender, EventArgs e)
        {
            tbDate.Text = Calendar2.SelectedDate.ToShortDateString();
            tbDate.Text = Calendar2.SelectedDate.ToString(" MMMM dd, yyyy");
            Calendar2.Visible = false;
            ddyear.Visible = false;
            ddmonth.Visible = false;
            lblyear.Visible = false;
            lblmonth.Visible = false;

            DateTime startdate = Calendar2.SelectedDate;
            DateTime enddate = DateTime.Now;
            tbage.Text = CalcAge(enddate, startdate).ToString();
        }
        public long CalcAge(System.DateTime StartDate, System.DateTime EndDate)
        {
            long age = 0;
            System.TimeSpan ts = new TimeSpan(StartDate.Ticks - EndDate.Ticks);
            age = (long)(ts.Days / 365);
            return age;
        }

        protected void EditButton_Click(object sender, ImageClickEventArgs e)
        {
            enable();
        }

        protected void DeleteButton_Click(object sender, ImageClickEventArgs e)
        {

        }
        public void reserve()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_onlineapplicant ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvReserve.DataSource = dt;
            gvReserve.DataBind();
        }
    }
}