﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class CompanyPosting_form : System.Web.UI.Page

    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected int widesData;
        protected void Page_Load(object sender, EventArgs e)
        {
            company();
            head();
            search();
            requirecomplete();
        }

        public void search()
        {
            if (ddSearch.Text == "Company_Name")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Company_Name like '%'+@Company_Name+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Company_Name", lblcompname.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }
        }
        
        public void requirecomplete()
        {
            if (require.Text == "Not Complete")
            {
                hlreq.Visible = true;
            }
            else if (require.Text == "Complete")
            {
                hlreq.Visible = false;
            }
        }


        private void notify()
        {
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential("caloocanpeso21@gmail.com", "joloairagenachavez");
            smtp.EnableSsl = true;
            MailMessage msg = new MailMessage();
            msg.Subject = "Company Posting Job Vacancy";
            msg.Body = " " + lblcompname.Text + ", is have a new post Job Vacancy Click LINK to Check Post http://pesocaloocan-001-site1.dtempurl.com/Comprec_form.aspx  \n\n\nThanks ";
            string toaddress = lblemail.Text;
            msg.To.Add(toaddress);
            string fromaddress = "caloocanpeso21@gmail.com";
            msg.From = new MailAddress(fromaddress);
            try
            {
                smtp.Send(msg);
            }
            catch
            {
                throw;
            }
        }
















        public void head()
        {
            
            lblcompemail.Text = "" + Session["email"];
            lblposition.Text = "" + Session["position"];
            lblhead.Text = "" + Session["head_name"];
            lblcompname.Text = "" + Session["company_name"];
            lbldept.Text = "" + Session["department"];
            address.Text = Session["address"].ToString();
            barangay.Text = Session["brgy"].ToString();
            city.Text = Session["town_city"].ToString();
            district.Text = Session["district"].ToString();



            //fileupdload
            require.Text = "" + Session["requirements"];
            compid.Text = "" + Session["company_id"];
            intent.Text = "" + Session["letterofintent"];
            comprof.Text = "" + Session["companyprofile"];
            businessper.Text = "" + Session["businesspermit"];
            dti.Text = "" + Session["dti"];
            bir.Text = "" + Session["bir"];
            dole.Text = "" + Session["dole"];
            poea.Text = "" + Session["poea"];
            nota.Text = "" + Session["notarized"];
            
            
        }

        public void company()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_companies where  Company_Name='" + lblcompname.Text + "' AND Approval='Approved' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvCompany.DataSource = dt;
            gvCompany.DataBind();
        }

        protected void gvCompany_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        //Row
                        gvCompany.Columns[0].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[1].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[2].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[3].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[4].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[5].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[6].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[7].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[8].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[9].ItemStyle.Width = widesData * 50;
                       
                   
                        
                        


                        gvCompany.Columns[0].ItemStyle.Wrap = false;
                        gvCompany.Columns[1].ItemStyle.Wrap = false;
                        gvCompany.Columns[2].ItemStyle.Wrap = false;
                        gvCompany.Columns[3].ItemStyle.Wrap = false;
                        gvCompany.Columns[4].ItemStyle.Wrap = false;
                        gvCompany.Columns[5].ItemStyle.Wrap = false;
                        gvCompany.Columns[6].ItemStyle.Wrap = false;
                        gvCompany.Columns[7].ItemStyle.Wrap = false;
                        gvCompany.Columns[8].ItemStyle.Wrap = false;
                        gvCompany.Columns[9].ItemStyle.Wrap = false;
                       
              
                        
                        //Head
                        gvCompany.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[8].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[9].HeaderStyle.Width = widesData * 50;
                        
         
                        
                        


                        gvCompany.Columns[0].HeaderStyle.Wrap = false;
                        gvCompany.Columns[1].HeaderStyle.Wrap = false;
                        gvCompany.Columns[2].HeaderStyle.Wrap = false;
                        gvCompany.Columns[3].HeaderStyle.Wrap = false;
                        gvCompany.Columns[4].HeaderStyle.Wrap = false;
                        gvCompany.Columns[5].HeaderStyle.Wrap = false;
                        gvCompany.Columns[6].HeaderStyle.Wrap = false;
                        gvCompany.Columns[7].HeaderStyle.Wrap = false;
                        gvCompany.Columns[8].HeaderStyle.Wrap = false;
                        gvCompany.Columns[9].HeaderStyle.Wrap = false;
               
         
                        
                        
                    }

                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (require.Text == "Not Complete")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('You did not meet the Requirements or wait for updating of PESO CALOOCAN of your Account Thanks');</script>");
            }
            else
            {
                submit();
            }
        }

        public void submit()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_companies  values('" + ddskills.Text + "','" + lblhead.Text + "','" + lblposition.Text + "','" + lbldept.Text + "','" + lblcompname.Text + "','" + address.Text + "','" + barangay.Text + "','" + city.Text + "','" + district.Text + "','" + tbVacancy.Text + "','" + ddStatus.Text + "','" + tbQuali1.Text + "','" + tbQuali2.Text + "','" + tbQuali3.Text + "','" + tbQuali4.Text + "','" + tbQuali5.Text + "','Decline','" + lblcompemail.Text + "','" + tbOthers.Text + "')";
            cmd.ExecuteNonQuery();
            notify();
            clear();
            con.Close();
            Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Vacancy Post Successful Wait for some time Admin will Approve your post. ');</script>");
            


        }
        public void clear()
        {
            tbOthers.Text = "";
            tbVacancy.Text = "";
            ddStatus.Text = "";
            tbQuali1.Text = "";
            tbQuali2.Text = "";
            tbQuali3.Text = "";
            tbQuali4.Text = "";
            tbQuali5.Text = "";
        }

        protected void ddskills_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddskills.Text == "Others")
            {
                ddskills.Visible = false;
                btnClose.Visible = true;
                tbOthers.Visible = true;
               
            }
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            ddskills.Visible = true;
            btnClose.Visible = false;
            tbOthers.Visible = false;
            
        }

        protected void gvCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = gvCompany.SelectedRow;
            //Applicant
            lblid.Text = gr.Cells[3].Text;
            ddskills.Text = gr.Cells[1].Text;
            tbVacancy.Text = gr.Cells[5].Text;
            ddStatus.Text = gr.Cells[6].Text;
            tbQuali1.Text = gr.Cells[7].Text;
            tbQuali2.Text = gr.Cells[8].Text;
            tbQuali3.Text = gr.Cells[9].Text;
            tbQuali4.Text = gr.Cells[10].Text;
            tbQuali5.Text = gr.Cells[11].Text;
            btnDelete.Visible = true;
            btnUpdate.Visible = true;

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("CompanyPosting_form.aspx");
            btnDelete.Visible = false;
            btnUpdate.Visible = false;
            clear();
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            using (SqlCommand com = new SqlCommand("DELETE FROM tb_companies WHERE Company_Id=@ID", con))
            {
                com.Parameters.AddWithValue("@ID", lblid.Text);
                com.ExecuteNonQuery();
                gvCompany.DataBind();
                clear();
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            updatedata();
        }
        public void updatedata()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {

                string query = "UPDATE tb_companies SET Vacancy = @vacancy,Skills_Needed = @Skills_Needed,Status = @status,Quali_1 = @quali1,Quali_2 = @quali2,Quali_3 = @quali3,Quali_4 = @quali4,Quali_5 = @quali5 where Company_Id = @Company_Id ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@Company_Id", lblid.Text);
                cmd.Parameters.AddWithValue("@vacancy", tbVacancy.Text);
                cmd.Parameters.AddWithValue("@Skills_Needed", ddskills.Text);
                cmd.Parameters.AddWithValue("@others", tbOthers.Text);
                cmd.Parameters.AddWithValue("@status", ddStatus.Text);
                cmd.Parameters.AddWithValue("@quali1", tbQuali1.Text);
                cmd.Parameters.AddWithValue("@quali2", tbQuali2.Text);
                cmd.Parameters.AddWithValue("@quali3", tbQuali3.Text);
                cmd.Parameters.AddWithValue("@quali4", tbQuali4.Text);
                cmd.Parameters.AddWithValue("@quali5", tbQuali5.Text);
                

                cmd.Connection.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    gvCompany.DataBind();
                    
                    clear();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);

                }
            }
        }

    }
}