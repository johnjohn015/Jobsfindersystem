using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PESO3
{
    public partial class ApplicantRec_form : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();


            if (!IsPostBack)
            {
                Calendar1.Visible = false;
                ddyear.Visible = false;
                ddmonth.Visible = false;
                lblyear.Visible = false;
                lblmonth.Visible = false;

                DataSet years = new DataSet();
                years.ReadXml(Server.MapPath("~/Year.xml"));

                ddyear.DataTextField = "Number";
                ddyear.DataTextField = "Number";

                ddyear.DataSource = years;
                ddyear.DataBind();

                DataSet months = new DataSet();
                months.ReadXml(Server.MapPath("~/Month.xml"));

                ddmonth.DataTextField = "Name";
                ddmonth.DataTextField = "Number";

                ddmonth.DataSource = months;
                ddmonth.DataBind();
            }










            applicant();
        }
        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }

        public void access()
        {
            if (lblrole.Text == "Admin")
            {

            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }

        public void applicant()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_applicants ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvApplicant.DataSource = dt;
            gvApplicant.DataBind();
        }
        public void delete()
        {
            con.Open();
            using (SqlCommand com = new SqlCommand("DELETE FROM tb_applicants WHERE applicant_number=@applicant_number", con))
            {
                com.Parameters.AddWithValue("@applicant_number", tbId.Text);
                com.ExecuteNonQuery();
                gvApplicant.DataBind();
                clear();
            }
        }
        public void enabled()
        {
            tbfname.Enabled = true;
            tbmname.Enabled = true;
            tblname.Enabled = true;
            tbaddress.Enabled = true;
            tbbrgy.Enabled = true;
            tbcity.Enabled = true;
            tbdistrict.Enabled = true;
            ddgender.Enabled = true;
            tbage.Enabled = true;
            ddskills.Enabled = true;
            tbeduc.Enabled = true;
            tbposition.Enabled = true;
            tbworkexp.Enabled = true;
            tbcompexp.Enabled = true;
            tbyear.Enabled = true;
            tbemail.Enabled = true;
            ImageButton2.Enabled = true;
            btnSave.Enabled = true;

        }

        public void disable()
        {
            tbfname.Enabled = false;
            tbmname.Enabled = false;
            tblname.Enabled = false;
            tbaddress.Enabled = false;
            tbbrgy.Enabled = false;
            tbcity.Enabled = false;
            tbdistrict.Enabled = false;
            ddgender.Enabled = false;
            tbage.Enabled = false;
            ddskills.Enabled = false;
            tbeduc.Enabled = false;
            tbposition.Enabled = false;
            tbworkexp.Enabled = false;
            tbcompexp.Enabled = false;
            tbyear.Enabled = false;
            ImageButton2.Enabled = false;
            btnSave.Enabled = false;
            tbemail.Enabled = false;
            EditButton.Enabled = false;
            DeleteButton.Enabled = false;

        }

        public void clear()
        {
            tbfname.Text = "";
            tbmname.Text = "";
            tblname.Text = "";
            tbaddress.Text = "";
            tbbrgy.Text = "";
            tbcity.Text = "";
            tbdistrict.Text = "";
            ddgender.Text = "Male";
            tbage.Text = "";
            ddskills.Text = "";
            tbeduc.Text = "";
            tbposition.Text = "";
            tbworkexp.Text = "";
            tbcompexp.Text = "";
            tbyear.Text = "";
            tbDate.Text = "";
            tbemail.Text = "";
            disable();

        }

        public void updatedata()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {
                string query = "UPDATE tb_applicants SET fname = @fname,mname=@mname,lname = @lname, address = @address,brgy =@brgy,town_city = @town_city,district = @district,dob = @dob,age = @age,gender = @gender,educational_attainment = @educ,work_skills = @workskills,other_work_skills = @other_work_skills,work_experience = @work_experience,company_work_experience = @company_work_experience,year_experience = @year_experience ,email = @email, position_applied_for = @position where applicant_number = @applicant_number ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@applicant_number", tbId.Text);
                cmd.Parameters.AddWithValue("@position", tbposition.Text);
                cmd.Parameters.AddWithValue("@fname", tbfname.Text);
                cmd.Parameters.AddWithValue("@mname", tbmname.Text);
                cmd.Parameters.AddWithValue("@lname", tblname.Text);
                cmd.Parameters.AddWithValue("@address", tbaddress.Text);
                cmd.Parameters.AddWithValue("@brgy", tbbrgy.Text);
                cmd.Parameters.AddWithValue("@town_city", tbcity.Text);
                cmd.Parameters.AddWithValue("@district", tbdistrict.Text);
                cmd.Parameters.AddWithValue("@dob", tbDate.Text);
                cmd.Parameters.AddWithValue("@gender", ddgender.Text);
                cmd.Parameters.AddWithValue("@age", tbage.Text);
                cmd.Parameters.AddWithValue("@educ", tbeduc.Text);
                cmd.Parameters.AddWithValue("@workskills", ddskills.Text);
                cmd.Parameters.AddWithValue("@other_work_skills", tbOthers.Text);
                cmd.Parameters.AddWithValue("@work_experience", tbworkexp.Text);
                cmd.Parameters.AddWithValue("@company_work_experience", tbcompexp.Text);
                cmd.Parameters.AddWithValue("@year_experience", tbyear.Text);
                cmd.Parameters.AddWithValue("@email", tbemail.Text);
               
               


                cmd.Connection.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                    gvApplicant.DataBind();

                    clear();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);
                }
            }
        }

        private int widestdata;

        protected void gvApplicant_RowDataBound1(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widestdata)
                    {
                        widestdata = catNameLen;
                        // Row
                        gvApplicant.Columns[0].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[1].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[2].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[3].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[4].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[5].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[6].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[7].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[8].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[9].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[10].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[11].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[12].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[13].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[14].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[15].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[16].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[17].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[18].ItemStyle.Width = widestdata * 50;



                        gvApplicant.Columns[0].ItemStyle.Wrap = false;
                        gvApplicant.Columns[1].ItemStyle.Wrap = false;
                        gvApplicant.Columns[2].ItemStyle.Wrap = false;
                        gvApplicant.Columns[3].ItemStyle.Wrap = false;
                        gvApplicant.Columns[4].ItemStyle.Wrap = false;
                        gvApplicant.Columns[5].ItemStyle.Wrap = false;
                        gvApplicant.Columns[6].ItemStyle.Wrap = false;
                        gvApplicant.Columns[7].ItemStyle.Wrap = false;
                        gvApplicant.Columns[8].ItemStyle.Wrap = false;
                        gvApplicant.Columns[9].ItemStyle.Wrap = false;
                        gvApplicant.Columns[10].ItemStyle.Wrap = false;
                        gvApplicant.Columns[11].ItemStyle.Wrap = false;
                        gvApplicant.Columns[12].ItemStyle.Wrap = false;
                        gvApplicant.Columns[13].ItemStyle.Wrap = false;
                        gvApplicant.Columns[14].ItemStyle.Wrap = false;
                        gvApplicant.Columns[15].ItemStyle.Wrap = false;
                        gvApplicant.Columns[16].ItemStyle.Wrap = false;
                        gvApplicant.Columns[17].ItemStyle.Wrap = false;
                        gvApplicant.Columns[18].ItemStyle.Wrap = false;
                        




                        //head

                        gvApplicant.Columns[0].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[1].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[2].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[3].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[4].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[5].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[6].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[7].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[8].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[9].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[10].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[11].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[12].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[13].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[14].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[15].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[16].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[17].HeaderStyle.Width = widestdata * 50;
                        gvApplicant.Columns[18].HeaderStyle.Width = widestdata * 50;




                        gvApplicant.Columns[0].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[1].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[2].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[3].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[4].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[5].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[6].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[7].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[8].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[9].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[10].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[11].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[12].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[13].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[14].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[15].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[16].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[17].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[18].HeaderStyle.Wrap = false;


                    }

                }
            }
        }

        protected void gvApplicant_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = gvApplicant.SelectedRow;
            tbposition.Text = gr.Cells[1].Text;
            tbId.Text = gr.Cells[2].Text;
            tbfname.Text = gr.Cells[3].Text;
            tbmname.Text = gr.Cells[4].Text;
            tblname.Text = gr.Cells[5].Text;
            tbaddress.Text = gr.Cells[6].Text;
            tbbrgy.Text = gr.Cells[7].Text;
            tbcity.Text = gr.Cells[8].Text;
            tbdistrict.Text = gr.Cells[9].Text;
            tbDate.Text = gr.Cells[10].Text;
            tbage.Text = gr.Cells[11].Text;
            ddgender.Text = gr.Cells[12].Text;
            tbemail.Text = gr.Cells[13].Text;
            tbeduc.Text = gr.Cells[14].Text;
            ddskills.Text = gr.Cells[15].Text;
            tbOthers.Text = gr.Cells[16].Text;
           
            tbworkexp.Text = gr.Cells[17].Text;
            tbcompexp.Text = gr.Cells[18].Text;
            tbyear.Text = gr.Cells[19].Text;
            EditButton.Enabled = true;
            DeleteButton.Enabled = true;

        }
         
        public void search()
        {
             if (ddSearch.Text == "position_applied_for")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where position_applied_for like '%'+@position_applied_for+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("position_applied_for", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }
             else if (ddSearch.Text == "applicant_number")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from applicant_number where id like '%'+@applicant_number+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("applicant_number", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            else if (ddSearch.Text == "fname")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where fname like '%'+@fname+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("fname", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            else if (ddSearch.Text == "mname")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where mname like '%'+@mname+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("mname", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            else if (ddSearch.Text == "lname")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where lname like '%'+@lname+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("lname", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            else if (ddSearch.Text == "address")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where address like '%'+@address+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("address", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }
            else if (ddSearch.Text == "brgy")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where brgy like '%'+@brgy+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("brgy", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            else if (ddSearch.Text == "city")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where city like '%'+@city+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("city", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            else if (ddSearch.Text == "district")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where district like '%'+@district+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("district", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            else if (ddSearch.Text == "age")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where age like '%'+@age+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("age", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            else if (ddSearch.Text == "gender")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where gender like '%'+@gender+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("gender", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

           

            else if (ddSearch.Text == "educational_attainment")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where educational_attainment like '%'+@educational_attainment+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("educational_attainment", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            else if (ddSearch.Text == "work_skills")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where work_skills like '%'+@work_skills+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("work_skills", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }
            else if (ddSearch.Text == "work_experience")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where work_experience like '%'+@work_experience+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("work_experience", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }
            else if (ddSearch.Text == "company_work_experience")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where company_work_experience like '%'+@company_work_experience+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("company_work_experience", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }
            else if (ddSearch.Text == "year_experience")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_applicants where year_experience like '%'+@year_experience+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("year_experience", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvApplicant.DataSource = sdt;
                gvApplicant.DataBind();

            }

            

            
        }

        


        
        
        

        

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            search();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            updatedata();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            clear();
        }

        protected void EditButton_Click(object sender, ImageClickEventArgs e)
        {
            enabled();
        }

        protected void DeleteButton_Click(object sender, ImageClickEventArgs e)
        {
            delete();
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
                ddyear.Visible = false;
                ddmonth.Visible = false;
                lblyear.Visible = false;
                lblmonth.Visible = false;

                tbDate.Text = "";
            }
            else
            {
                Calendar1.Visible = true;
                ddyear.Visible = true;
                ddmonth.Visible = true;
                lblyear.Visible = true;
                lblmonth.Visible = true;
            }

                
        }

        public void dob()
        {
            tbDate.Text = Calendar1.SelectedDate.ToString(" MMMM dd, yyyy");
            Calendar1.Visible = false;
        }

        protected void ddyear_SelectedIndexChanged(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar1.VisibleDate = new DateTime(year, month, 1);
            Calendar1.SelectedDate = new DateTime(year, month, 1);
        }

        protected void ddmonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar1.VisibleDate = new DateTime(year, month, 1);
            Calendar1.SelectedDate = new DateTime(year, month, 1);
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            tbDate.Text = Calendar1.SelectedDate.ToShortDateString();
            tbDate.Text = Calendar1.SelectedDate.ToString(" MMMM dd, yyyy");
            Calendar1.Visible = false;
            ddyear.Visible = false;
            ddmonth.Visible = false;
            lblyear.Visible = false;
            lblmonth.Visible = false;

            DateTime startdate = Calendar1.SelectedDate;
            DateTime enddate = DateTime.Now;
            tbage.Text = CalcAge(enddate, startdate).ToString();
        }

        public long CalcAge(System.DateTime StartDate, System.DateTime EndDate)
        {
            long age = 0;
            System.TimeSpan ts = new TimeSpan(StartDate.Ticks - EndDate.Ticks);
            age = (long)(ts.Days / 365);
            return age;
        }
        
    }

}