﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;


namespace PESO3
{
    public partial class reserve : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        DataSet ds = new DataSet();
        SqlCommand com;
        string str;
        SqlCommand coms;
        string strs;
        static String resumelink;
        static Int32 applicationid;
        static String activationcode;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Calendar2.Visible = false;
                ddyear.Visible = false;
                ddmonth.Visible = false;
                lblyear.Visible = false;
                lblmonth.Visible = false;

               

                DataSet years = new DataSet();
                years.ReadXml(Server.MapPath("~/Year.xml"));

                ddyear.DataTextField = "Number";
                ddyear.DataTextField = "Number";

                ddyear.DataSource = years;
                ddyear.DataBind();

                DataSet months = new DataSet();
                months.ReadXml(Server.MapPath("~/Month.xml"));

                ddmonth.DataTextField = "Name";
                ddmonth.DataTextField = "Number";

                ddmonth.DataSource = months;
                ddmonth.DataBind();


                
            }

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            validation();
        }

        
        public void validation()
        {
            if (tbfname.Text == "" || tblname.Text == "" || tbaddress.Text == "" || tbDate.Text == "" || ddgender.Text == "" || tbemail.Text == "" || ddskills.Text == "" || tbuser.Text == "" || tbpassword.Text == "" || tbconfirm.Text == "")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Please Fill up Empty Field');</script>");
                val1.Visible = true;
                val2.Visible = true;
                val3.Visible = true;
                val4.Visible = true;
                val5.Visible = true;
                val6.Visible = true;
                val7.Visible = true;
                val8.Visible = true;
                val9.Visible = true;


            }
            else
            {
                submit();
            }
        }

        private void notify()
        {
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential("caloocanpeso21@gmail.com", "joloairagenachavez");
            smtp.EnableSsl = true;
            MailMessage msg = new MailMessage();
            msg.Subject = "Requesting Appoinment And User Approval";
            msg.Body = " " + tbfname.Text + " " + tbmname.Text + " " + tblname.Text + ", is asking for an appointment and approval of the user \n\n\nThanks ";
            string toaddress = "caloocanpeso21@gmail.com";
            msg.To.Add(toaddress);
            string fromaddress = tbemail.Text;
            msg.From = new MailAddress(fromaddress);
            try
            {
                smtp.Send(msg);
            }
            catch
            {
                throw;
            }
        }

        private Boolean uploadresume()
        {
            Boolean resumesaved = false;
            if (FileUpload1.HasFile == true)
            {

                String contenttype = FileUpload1.PostedFile.ContentType;

                if (contenttype == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload1.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload1.SaveAs(Server.MapPath("~/UploadResumee/") + applicationid + ".pdf");

                    resumelink = "UploadResumee/" + applicationid + ".pdf";
                    resumesaved = true;

                }

                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload Resume in PDF Format Only');</script>");
                }

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Upload Resume Before Apply in PDF Format');</script>");
            }


            return resumesaved;
        }
        public void getapplicationid()
        {

            String myquery = "select applicant_number from tb_onlineapplicant";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = myquery;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count < 1)
            {
                applicationid = 10001;

            }
            else
            {




                String myquery1 = "select max(applicant_number) from tb_onlineapplicant";
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandText = myquery1;
                cmd1.Connection = con;
                SqlDataAdapter da1 = new SqlDataAdapter();
                da1.SelectCommand = cmd1;
                DataSet ds1 = new DataSet();
                da1.Fill(ds1);
                applicationid = Convert.ToInt32(ds1.Tables[0].Rows[0][0].ToString());
                applicationid = applicationid + 1;
                con.Close();
            }

        }
        public void clear()
        {
            
            tbfname.Text = "";
            tbmname.Text = "";
            tblname.Text = "";
            tbaddress.Text = "";
            tbbrgy.Text = "";
            tbcity.Text = "";
            tbdistrict.Text = "";
            tbDate.Text = "";
         
            tbage.Text = "";
            ddgender.Text = "";
            tbemail.Text = "";
            tbuser.Text = "";
            tbpassword.Text = "";
            tbconfirm.Text = "";

            Calendar2.Visible = false;
            ddyear.Visible = false;
            ddmonth.Visible = false;
            lblyear.Visible = false;
            lblmonth.Visible = false;
        }
       
        
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
                ddyear.Visible = false;
                ddmonth.Visible = false;
                lblyear.Visible = false;
                lblmonth.Visible = false;

                tbDate.Text = "";
            }
            else
            {
                Calendar2.Visible = true;
                ddyear.Visible = true;
                ddmonth.Visible = true;
                lblyear.Visible = true;
                lblmonth.Visible = true;
            }
        }
        public void submit()
        {
            SqlConnection cons1 = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
                cons1.Open();
                str = "select count(*)from tb_onlineapplicant where email='" + tbemail.Text + "'";
                com = new SqlCommand(str, cons1);
                int count1 = Convert.ToInt32(com.ExecuteScalar());
                if (count1 > 0)
                {

                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Already Use Email.');</script>");
                    ds.Clear();

                }

                else
                {
                    if (uploadresume() == true)
                    {
                        String query = "insert into tb_onlineapplicant values('" + tbfname.Text + "','" + tbmname.Text + "','" + tblname.Text + "','" + tbaddress.Text + "','" + tbbrgy.Text + "','" + tbcity.Text + "','" + tbdistrict.Text + "','" + tbDate.Text + "','" + tbage.Text + "','" + ddgender.Text + "','" + tbemail.Text + "','N/A','N/A','" + resumelink + "','" + ddskills.Text + "','" + tbuser.Text + "','" + tbpassword.Text + "','" + tbconfirm.Text + "','" + tbOthers.Text + "','disapproved')";
                        con.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.CommandText = query;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();
                        notify();
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Your Application ID is " + applicationid.ToString() + "Thanks For Using Online Apppointment and Wait for your Date and Time of your Interview.');</script>");
                        clear();

                    }
                
            }
        }

        protected void ddyear_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ddmonth_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Calendar2_SelectionChanged1(object sender, EventArgs e)
        {
            tbDate.Text = Calendar2.SelectedDate.ToShortDateString();
            tbDate.Text = Calendar2.SelectedDate.ToString(" MMMM dd, yyyy");
            Calendar2.Visible = false;
            ddyear.Visible = false;
            ddmonth.Visible = false;
            lblyear.Visible = false;
            lblmonth.Visible = false;

            DateTime startdate = Calendar2.SelectedDate;
            DateTime enddate = DateTime.Now;
            tbage.Text = CalcAge(enddate, startdate).ToString();
        }

        public long CalcAge(System.DateTime StartDate, System.DateTime EndDate)
        {
            long age = 0;
            System.TimeSpan ts = new TimeSpan(StartDate.Ticks - EndDate.Ticks);
            age = (long)(ts.Days / 365);
            return age;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

        }

        protected void Calendar3_DayRender(object sender, DayRenderEventArgs e)
        {
            if (e.Day.IsWeekend)
            {

                e.Cell.Font.Strikeout = true;
                e.Day.IsSelectable = false;

            }
            if (e.Day.IsOtherMonth)
            {
                e.Day.IsSelectable = false;

            }
        }

        

        protected void ddyear_SelectedIndexChanged1(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar2.VisibleDate = new DateTime(year, month, 1);
            Calendar2.SelectedDate = new DateTime(year, month, 1);
        }

        protected void ddmonth_SelectedIndexChanged1(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar2.VisibleDate = new DateTime(year, month, 1);
            Calendar2.SelectedDate = new DateTime(year, month, 1);
        }

        protected void ddskills_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddskills.Text == "Others")
            {
                ddskills.Visible = false;
                btnClose.Visible = true;
                tbOthers.Visible = true;

            }
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            ddskills.Visible = true;
            btnClose.Visible = false;
            tbOthers.Visible = false;
        }

        
    }
}