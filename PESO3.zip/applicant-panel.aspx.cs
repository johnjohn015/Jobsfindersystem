﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class applicant_panel : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        DataSet ds = new DataSet();
        SqlCommand com;
        string str;
        SqlCommand coms;
        string strs;
        static String resumelink;
        static Int32 applicationid;
        static String activationcode;
        protected void Page_Load(object sender, EventArgs e)
        {
            data();
           
                Calendar2.Visible = false;
                ddyear.Visible = false;
                ddmonth.Visible = false;
                lblyear.Visible = false;
                lblmonth.Visible = false;



                DataSet years = new DataSet();
                years.ReadXml(Server.MapPath("~/Year.xml"));

                ddyear.DataTextField = "Number";
                ddyear.DataTextField = "Number";

                ddyear.DataSource = years;
                ddyear.DataBind();

                DataSet months = new DataSet();
                months.ReadXml(Server.MapPath("~/Month.xml"));

                ddmonth.DataTextField = "Name";
                ddmonth.DataTextField = "Number";

                ddmonth.DataSource = months;
                ddmonth.DataBind();

                reserve();

            
        }
        public void data()
        {
            id.Text = "" + Session["applicant_number"];
            ddskills.Text = "" + Session["skills"];
            tbfname.Text = "" + Session["fname"];
            tbmname.Text = "" + Session["mname"];
            tblname.Text = "" + Session["lname"];
            tbaddress.Text = "" + Session["address"];
            tbbrgy.Text = "" + Session["brgy"];
            tbcity.Text = "" + Session["city"];
            tbdistrict.Text = "" + Session["district"];
            tbDate.Text = "" + Session["dob"];
            tbage.Text = "" + Session["age"];
            ddgender.Text = "" + Session["gender"];
            tbemail.Text = "" + Session["email"];
            Date.Text = "" + Session["schedule_interview"];
            Time.Text = "" + Session["time_interview"];
            tbuser.Text = "" + Session["username"];
            tbpassword.Text = "" + Session["password"];
            tbconfirm.Text = "" + Session["confirmpass"];
        }
       
       

        protected void EditButton_Click(object sender, ImageClickEventArgs e)
        {
            enable();
        }
       
        
        public void enable()
        {
            tbfname.Enabled = true;
            tbmname.Enabled = true;
            tblname.Enabled = true;
            tbaddress.Enabled = true;
            tbbrgy.Enabled = true;
            tbcity.Enabled = true;
            tbdistrict.Enabled = true;
            tbDate.Enabled = true;
            FileUpload1.Enabled = true;
            tbage.Enabled = true;
            ddgender.Enabled = true;
            tbemail.Enabled = true;
            tbuser.Enabled = true;
            tbpassword.Enabled = true;
            tbconfirm.Enabled = true;
            btnSave.Visible = true;
            btnCancel.Visible = true;
        }
        public void disable()
        {
            tbfname.Enabled = false;
            tbmname.Enabled = false;
            tblname.Enabled = false;
            tbaddress.Enabled = false;
            tbbrgy.Enabled = false;
            tbcity.Enabled = false;
            tbdistrict.Enabled = false;
            tbDate.Enabled = false;

            tbage.Enabled = false;
            ddgender.Enabled = false;
            tbemail.Enabled = false;
            tbuser.Enabled = false;
            tbpassword.Enabled = false;
            tbconfirm.Enabled = false;
            btnSave.Visible = false;
            btnCancel.Visible = false;
        }

        protected void ddskills_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddskills.Text == "Others")
            {
                ddskills.Visible = false;
                btnClose.Visible = true;
                tbOthers.Visible = true;

            }
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            ddskills.Visible = true;
            btnClose.Visible = false;
            tbOthers.Visible = false;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
                ddyear.Visible = false;
                ddmonth.Visible = false;
                lblyear.Visible = false;
                lblmonth.Visible = false;

                tbDate.Text = "";
            }
            else
            {
                Calendar2.Visible = true;
                ddyear.Visible = true;
                ddmonth.Visible = true;
                lblyear.Visible = true;
                lblmonth.Visible = true;
            }
        }

        protected void ddyear_SelectedIndexChanged1(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar2.VisibleDate = new DateTime(year, month, 1);
            Calendar2.SelectedDate = new DateTime(year, month, 1);
        }

        protected void ddmonth_SelectedIndexChanged1(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar2.VisibleDate = new DateTime(year, month, 1);
            Calendar2.SelectedDate = new DateTime(year, month, 1);
        }

        protected void Calendar2_SelectionChanged1(object sender, EventArgs e)
        {
            tbDate.Text = Calendar2.SelectedDate.ToShortDateString();
            tbDate.Text = Calendar2.SelectedDate.ToString(" MMMM dd, yyyy");
            Calendar2.Visible = false;
            ddyear.Visible = false;
            ddmonth.Visible = false;
            lblyear.Visible = false;
            lblmonth.Visible = false;

            DateTime startdate = Calendar2.SelectedDate;
            DateTime enddate = DateTime.Now;
            tbage.Text = CalcAge(enddate, startdate).ToString();
        }
        public long CalcAge(System.DateTime StartDate, System.DateTime EndDate)
        {
            long age = 0;
            System.TimeSpan ts = new TimeSpan(StartDate.Ticks - EndDate.Ticks);
            age = (long)(ts.Days / 365);
            return age;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            disable();
            
        }
        public void clear()
        {

            tbfname.Text = "";
            tbmname.Text = "";
            tblname.Text = "";
            tbaddress.Text = "";
            tbbrgy.Text = "";
            tbcity.Text = "";
            tbdistrict.Text = "";
            tbDate.Text = "";

            tbage.Text = "";
            ddgender.Text = "";
            tbemail.Text = "";
            tbuser.Text = "";
            tbpassword.Text = "";
            tbconfirm.Text = "";

            Calendar2.Visible = false;
            ddyear.Visible = false;
            ddmonth.Visible = false;
            lblyear.Visible = false;
            lblmonth.Visible = false;
        }

        
    

       

        public void updatedata()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {

                string query = "UPDATE tb_onlineapplicant SET fname = '"+tbfname.Text+"' where applicant_number = @applicant_number ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@applicant_number", id.Text);

             //   cmd.Parameters.AddWithValue("@fname", tbfname.Text);
      
                


                cmd.Connection.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    

                    
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);

                }
            }
        }
        public void reserve()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_onlineapplicant ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvReserve.DataSource = dt;
            gvReserve.DataBind();
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
           
           

        
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {

                string query = "UPDATE tb_onlineapplicant SET fname = @fname where applicant_number = @applicant_number ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@applicant_number", id.Text);
                cmd.Parameters.AddWithValue("@fname", tbfname.Text);
                

                cmd.Connection.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    gvReserve.DataBind();
                 
                    
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);

                }
            }
        }

        protected void gvReserve_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        }
}

        

       
        
    
