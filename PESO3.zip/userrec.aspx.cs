﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PESO3
{
    public partial class userrec : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected void Page_Load(object sender, EventArgs e)
        {
            accounts();
        }
        public void accounts()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_users ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvAccounts.DataSource = dt;
            gvAccounts.DataBind();
        }

        public void updatedata()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=(local)\SQLSERVERNEW;Initial Catalog=db_eis;Integrated Security=true;"))
            {

                string query = "UPDATE tb_users SET role = @role, fname = @fname, mname = @mname, lname = @lname, email = @email, username = @username, password = @password, confirmpass = @confirmpass, status = @status where UserId = @UserId ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@UserId", tbId.Text);
                cmd.Parameters.AddWithValue("@role", ddrole.Text);
                cmd.Parameters.AddWithValue("@fname", tbfname.Text);
                cmd.Parameters.AddWithValue("@mname", tbmname.Text);
                cmd.Parameters.AddWithValue("@lname", tblname.Text);
                cmd.Parameters.AddWithValue("@email", tbemail.Text);
                cmd.Parameters.AddWithValue("@username", tbusername.Text);
                cmd.Parameters.AddWithValue("@password", tbpassword.Text);
                cmd.Parameters.AddWithValue("@confirmpass", tbconfirm.Text);
                cmd.Parameters.AddWithValue("@status", ddstatus.Text);


                cmd.Connection.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    gvAccounts.DataBind();

                    clear();
                    disable();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);

                }
            }
        }

        public void clear()
        {
            tbId.Text = "";
            ddrole.Text = "";
            tbfname.Text = "";
            tbmname.Text = "";
            tblname.Text = "";
            tbemail.Text = "";
            tbusername.Text = "";
            tbpassword.Text = "";
            tbconfirm.Text = "";
            ddstatus.Text = "";
        }

        public void enable()
        {
            ddrole.Enabled = true;
            tbfname.Enabled = true;
            tbmname.Enabled = true;
            tblname.Enabled = true;
            tbemail.Enabled = true;
            tbusername.Enabled = true;
            tbpassword.Enabled = true;
            tbconfirm.Enabled = true;
            ddstatus.Enabled = true;
        }

        public void disable()
        {
            ddrole.Enabled = false;
            tbfname.Enabled = false;
            tbmname.Enabled = false;
            tblname.Enabled = false;
            tbemail.Enabled = false;
            tbusername.Enabled = false;
            tbpassword.Enabled = false;
            tbconfirm.Enabled = false;
            ddstatus.Enabled = false;
            EditButton.Enabled = false;
            DeleteButton.Enabled = false;
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            updatedata();
        }

        protected void gvAccounts_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = gvAccounts.SelectedRow;
            tbId.Text = gr.Cells[1].Text;
            ddrole.Text = gr.Cells[2].Text;
            tbfname.Text = gr.Cells[3].Text;
            tbmname.Text = gr.Cells[4].Text;
            tblname.Text = gr.Cells[5].Text;
            tbemail.Text = gr.Cells[6].Text;
            tbusername.Text = gr.Cells[7].Text;
            tbpassword.Text = gr.Cells[8].Text;
            tbconfirm.Text = gr.Cells[9].Text;
            ddstatus.Text = gr.Cells[10].Text;
            btnSave.Enabled = true;
            btnCancel.Enabled = true;
            EditButton.Enabled = true;
            DeleteButton.Enabled = true;
        }

        protected void gvAccounts_PreRender(object sender, EventArgs e)
        {
            foreach (GridViewRow row in gvAccounts.Rows)
            {

                string pwd = new string('*', row.Cells[8].Text.Length);
                string pwd2 = new string('*', row.Cells[9].Text.Length);

                row.Cells[8].Text = pwd;
                row.Cells[9].Text = pwd2;

            }
        }

        protected void EditButton_Click(object sender, ImageClickEventArgs e)
        {
            enable();
        }

        protected void DeleteButton_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            clear();
            disable();
        }
    }
}