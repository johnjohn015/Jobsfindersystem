﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class Comprec_form : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();
              company();
        }
        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }

        public void access()
        {
            if (lblrole.Text == "Admin")
            {

            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }
        public void company()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_companies ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvCompany.DataSource = dt;
            gvCompany.DataBind();
        }
        protected int widesData;

        protected void gvCompany_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        //Row
                        gvCompany.Columns[0].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[1].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[2].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[3].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[4].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[5].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[6].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[7].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[8].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[9].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[10].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[11].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[12].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[13].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[14].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[15].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[16].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[17].ItemStyle.Width = widesData * 50;


                        gvCompany.Columns[0].ItemStyle.Wrap = false;
                        gvCompany.Columns[1].ItemStyle.Wrap = false;
                        gvCompany.Columns[2].ItemStyle.Wrap = false;
                        gvCompany.Columns[3].ItemStyle.Wrap = false;
                        gvCompany.Columns[4].ItemStyle.Wrap = false;
                        gvCompany.Columns[5].ItemStyle.Wrap = false;
                        gvCompany.Columns[6].ItemStyle.Wrap = false;
                        gvCompany.Columns[7].ItemStyle.Wrap = false;
                        gvCompany.Columns[8].ItemStyle.Wrap = false;
                        gvCompany.Columns[9].ItemStyle.Wrap = false;
                        gvCompany.Columns[10].ItemStyle.Wrap = false;
                        gvCompany.Columns[11].ItemStyle.Wrap = false;
                        gvCompany.Columns[12].ItemStyle.Wrap = false;
                        gvCompany.Columns[13].ItemStyle.Wrap = false;
                        gvCompany.Columns[14].ItemStyle.Wrap = false;
                        gvCompany.Columns[15].ItemStyle.Wrap = false;
                        gvCompany.Columns[16].ItemStyle.Wrap = false;
                        gvCompany.Columns[17].ItemStyle.Wrap = false;
                        //Head
                        gvCompany.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[8].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[9].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[10].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[11].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[12].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[13].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[14].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[15].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[16].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[17].HeaderStyle.Width = widesData * 50;


                        gvCompany.Columns[0].HeaderStyle.Wrap = false;
                        gvCompany.Columns[1].HeaderStyle.Wrap = false;
                        gvCompany.Columns[2].HeaderStyle.Wrap = false;
                        gvCompany.Columns[3].HeaderStyle.Wrap = false;
                        gvCompany.Columns[4].HeaderStyle.Wrap = false;
                        gvCompany.Columns[5].HeaderStyle.Wrap = false;
                        gvCompany.Columns[6].HeaderStyle.Wrap = false;
                        gvCompany.Columns[7].HeaderStyle.Wrap = false;
                        gvCompany.Columns[8].HeaderStyle.Wrap = false;
                        gvCompany.Columns[9].HeaderStyle.Wrap = false;
                        gvCompany.Columns[10].HeaderStyle.Wrap = false;
                        gvCompany.Columns[11].HeaderStyle.Wrap = false;
                        gvCompany.Columns[12].HeaderStyle.Wrap = false;
                        gvCompany.Columns[13].HeaderStyle.Wrap = false;
                        gvCompany.Columns[14].HeaderStyle.Wrap = false;
                        gvCompany.Columns[15].HeaderStyle.Wrap = false;
                        gvCompany.Columns[16].HeaderStyle.Wrap = false;
                        gvCompany.Columns[17].HeaderStyle.Wrap = false;
                    }

                }
            }
        }

        protected void gvCompany_RowDataBound1(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        //Row
                        gvCompany.Columns[0].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[1].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[2].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[3].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[4].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[5].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[6].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[7].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[8].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[9].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[10].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[11].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[12].ItemStyle.Width = widesData * 50;
              


                        gvCompany.Columns[0].ItemStyle.Wrap = false;
                        gvCompany.Columns[1].ItemStyle.Wrap = false;
                        gvCompany.Columns[2].ItemStyle.Wrap = false;
                        gvCompany.Columns[3].ItemStyle.Wrap = false;
                        gvCompany.Columns[4].ItemStyle.Wrap = false;
                        gvCompany.Columns[5].ItemStyle.Wrap = false;
                        gvCompany.Columns[6].ItemStyle.Wrap = false;
                        gvCompany.Columns[7].ItemStyle.Wrap = false;
                        gvCompany.Columns[8].ItemStyle.Wrap = false;
                        gvCompany.Columns[9].ItemStyle.Wrap = false;
                        gvCompany.Columns[10].ItemStyle.Wrap = false;
                        gvCompany.Columns[11].ItemStyle.Wrap = false;
                        gvCompany.Columns[12].ItemStyle.Wrap = false;
           
                        //Head
                        gvCompany.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[8].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[9].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[10].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[11].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[12].HeaderStyle.Width = widesData * 50;
        


                        gvCompany.Columns[0].HeaderStyle.Wrap = false;
                        gvCompany.Columns[1].HeaderStyle.Wrap = false;
                        gvCompany.Columns[2].HeaderStyle.Wrap = false;
                        gvCompany.Columns[3].HeaderStyle.Wrap = false;
                        gvCompany.Columns[4].HeaderStyle.Wrap = false;
                        gvCompany.Columns[5].HeaderStyle.Wrap = false;
                        gvCompany.Columns[6].HeaderStyle.Wrap = false;
                        gvCompany.Columns[7].HeaderStyle.Wrap = false;
                        gvCompany.Columns[8].HeaderStyle.Wrap = false;
                        gvCompany.Columns[9].HeaderStyle.Wrap = false;
                        gvCompany.Columns[10].HeaderStyle.Wrap = false;
                        gvCompany.Columns[11].HeaderStyle.Wrap = false;
                        gvCompany.Columns[12].HeaderStyle.Wrap = false;

                    }

                }
            }
        }

        protected void gvCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = gvCompany.SelectedRow;
            ddskills.Text = gr.Cells[1].Text;
            tbOthers.Text = gr.Cells[2].Text;
            tbId.Text = gr.Cells[3].Text;
            tbCompanyName.Text = gr.Cells[4].Text;
            tbcompemail.Text = gr.Cells[5].Text;
            tbVacancy.Text = gr.Cells[6].Text;
            
            ddStatus.Text = gr.Cells[7].Text;
            tbQualification1.Text = gr.Cells[8].Text;
            tbQualification2.Text = gr.Cells[9].Text;
            tbQualification3.Text = gr.Cells[10].Text;
            tbQualification4.Text = gr.Cells[11].Text;
            tbQualification5.Text = gr.Cells[12].Text;
           
            EditButton.Enabled = true;
             DeleteButton.Enabled = true;
        }

        public void updatedata()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {

                string query = "UPDATE tb_companies SET  Company_Name = @compname,Vacancy = @vacancy,Skills_Needed = @Skills_Needed,Status = @status,Quali_1 = @quali1,Quali_2 = @quali2,Quali_3 = @quali3,Quali_4 = @quali4,Quali_5 = @quali5, Approval = @approval where Company_Id = @Company_Id ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@Company_Id", tbId.Text);
                cmd.Parameters.AddWithValue("@compname", tbCompanyName.Text);
                cmd.Parameters.AddWithValue("@vacancy", tbVacancy.Text);
                cmd.Parameters.AddWithValue("@Skills_Needed", ddskills.Text);
                cmd.Parameters.AddWithValue("@status", ddStatus.Text);
                cmd.Parameters.AddWithValue("@quali1", tbQualification1.Text);
                cmd.Parameters.AddWithValue("@quali2", tbQualification2.Text);
                cmd.Parameters.AddWithValue("@quali3", tbQualification3.Text);
                cmd.Parameters.AddWithValue("@quali4", tbQualification4.Text);
                cmd.Parameters.AddWithValue("@quali5", tbQualification5.Text);
                
                

                cmd.Connection.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    gvCompany.DataBind();
                    notify();
                    clear();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);
                    
                }
            }
        }


        private void notify()
        {
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential("caloocanpeso21@gmail.com", "joloairagenachavez");
            smtp.EnableSsl = true;
            MailMessage msg = new MailMessage();
            msg.Subject = "Company Posting Job Vacancy";
        //    msg.Body = " Dear " + tbCompanyName.Text + ", Your Post in Job Vacancy is "+rdapp.Text+" , \n\n\nThanks ";
            string toaddress = tbcompemail.Text;
            msg.To.Add(toaddress);
            string fromaddress = "caloocanpeso21@gmail.com";
            msg.From = new MailAddress(fromaddress);
            try
            {
                smtp.Send(msg);
            }
            catch
            {
                throw;
            }
        }





       


        protected void btnSave_Click(object sender, EventArgs e)
        {
            updatedata();
        }

        protected void EditButton_Click(object sender, ImageClickEventArgs e)
        {
            btnSave.Enabled = true;
            EditButton.Enabled = false;
            tbId.Enabled = true;
            tbCompanyName.Enabled = true;
            tbcompemail.Enabled = true;
            ddStatus.Enabled = true;
            tbQualification1.Enabled = true;
            tbQualification2.Enabled = true;
            tbQualification3.Enabled = true;
            tbQualification4.Enabled = true;
            tbQualification5.Enabled = true;
            
        }
        public void clear()
        {
            //enable
            EditButton.Enabled = true;
            //clear
            tbId.Text = "";
            tbCompanyName.Text = "";
            tbcompemail.Text = "";
            ddStatus.Text = "";
            tbQualification1.Text = "";
            tbQualification2.Text = "";
            tbQualification3.Text = "";
            tbQualification4.Text = "";
            tbQualification5.Text = "";
            
            //disable
            tbId.Enabled = false;
            tbCompanyName.Enabled = false;
            tbcompemail.Enabled = false;
            ddStatus.Enabled = false;
            tbQualification1.Enabled = false;
            tbQualification2.Enabled = false;
            tbQualification3.Enabled = false;
            tbQualification4.Enabled = false;
            tbQualification5.Enabled = false;
            
            btnSave.Enabled = false;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            //disable
            EditButton.Enabled = false;
            DeleteButton.Enabled = false;
            //clear
            tbId.Text = "";
            tbCompanyName.Text = "";
            tbcompemail.Text = "";
            ddStatus.Text = "";
            tbQualification1.Text = "";
            tbQualification2.Text = "";
            tbQualification3.Text = "";
            tbQualification4.Text = "";
            tbQualification5.Text = "";
           
            //disable
            tbId.Enabled = false;
            tbCompanyName.Enabled = false;
            tbcompemail.Enabled = false;
            ddStatus.Enabled = false;
            tbQualification1.Enabled = false;
            tbQualification2.Enabled = false;
            tbQualification3.Enabled = false;
            tbQualification4.Enabled = false;
            tbQualification5.Enabled = false;
            
            btnSave.Enabled = false;
        }

        protected void gvCompany_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
         
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
             con.Open();
             using (SqlCommand com = new SqlCommand("DELETE FROM tb_companies WHERE Company_Id=@ID", con))
             {
                 com.Parameters.AddWithValue("@ID", tbId.Text);
                 com.ExecuteNonQuery();
                 gvCompany.DataBind();
                 clear();
             }
            }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
             if (ddSearch.Text == "Skills_Needed")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Skills_Needed like '%'+@Skills_Needed+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Skills_Needed", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }
             else if (ddSearch.Text == "Company_Id")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Company_Id like '%'+@Company_Id+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Company_Id", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Head_Name")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Head_Name like '%'+@Head_Name+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Head_Name", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Position")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Position like '%'+@Position+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Position", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Department")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Department like '%'+@Department+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Position", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Company_Name")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Company_Name like '%'+@Company_Name+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Company_Name", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Address")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Address like '%'+@Address+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Address", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Brgy")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Brgy like '%'+@Brgy+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Brgy", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "City")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where City like '%'+@City+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("City", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "District")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where District like '%'+@District+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("District", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Vacancy")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Vacancy like '%'+@Vacancy+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Vacancy", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

           

            else if (ddSearch.Text == "Status")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Status like '%'+@Status+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Status", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Quali_1")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Quali_1 like '%'+@Quali_1+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Quali_1", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Quali_2")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Quali_2 like '%'+@Quali_2+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Quali_2", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Quali_3")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Quali_3 like '%'+@Quali_3+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Quali_3", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Quali_4")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Quali_4 like '%'+@Quali_4+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Quali_4", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

            else if (ddSearch.Text == "Quali_5")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Quali_5 like '%'+@Quali_5+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Quali_5", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }

             else if (ddSearch.Text == "Approval")
             {
                 con.Open();
                 SqlCommand cmd = new SqlCommand();
                 string sqlquery = "select * from tb_companies where Approval like '%'+@Approval+'%'";
                 cmd.CommandText = sqlquery;
                 cmd.Connection = con;
                 cmd.Parameters.AddWithValue("Approval", tbSearch.Text);
                 DataTable sdt = new DataTable();
                 SqlDataAdapter sda = new SqlDataAdapter(cmd);
                 sda.Fill(sdt);
                 gvCompany.DataSource = sdt;
                 gvCompany.DataBind();

             }
        }

        

        
    }
}