﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class vacancy : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected int widesData;
        protected void Page_Load(object sender, EventArgs e)
        {
            company();
        }
        public void company()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_companies where Approval = 'Approved' AND Status = 'Vacant' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvCompany.DataSource = dt;
            gvCompany.DataBind();
        }

        protected void gvCompany_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        //Row
                        gvCompany.Columns[0].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[1].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[2].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[3].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[4].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[5].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[6].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[7].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[8].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[9].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[10].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[11].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[12].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[13].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[14].ItemStyle.Width = widesData * 50;
                       


                        gvCompany.Columns[0].ItemStyle.Wrap = false;
                        gvCompany.Columns[1].ItemStyle.Wrap = false;
                        gvCompany.Columns[2].ItemStyle.Wrap = false;
                        gvCompany.Columns[3].ItemStyle.Wrap = false;
                        gvCompany.Columns[4].ItemStyle.Wrap = false;
                        gvCompany.Columns[5].ItemStyle.Wrap = false;
                        gvCompany.Columns[6].ItemStyle.Wrap = false;
                        gvCompany.Columns[7].ItemStyle.Wrap = false;
                        gvCompany.Columns[8].ItemStyle.Wrap = false;
                        gvCompany.Columns[9].ItemStyle.Wrap = false;
                        gvCompany.Columns[10].ItemStyle.Wrap = false;
                        gvCompany.Columns[11].ItemStyle.Wrap = false;
                        gvCompany.Columns[12].ItemStyle.Wrap = false;
                        gvCompany.Columns[13].ItemStyle.Wrap = false;
                        gvCompany.Columns[14].ItemStyle.Wrap = false;
                   
                        //Head
                        gvCompany.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[8].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[9].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[10].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[11].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[12].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[13].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[14].HeaderStyle.Width = widesData * 50;
                


                        gvCompany.Columns[0].HeaderStyle.Wrap = false;
                        gvCompany.Columns[1].HeaderStyle.Wrap = false;
                        gvCompany.Columns[2].HeaderStyle.Wrap = false;
                        gvCompany.Columns[3].HeaderStyle.Wrap = false;
                        gvCompany.Columns[4].HeaderStyle.Wrap = false;
                        gvCompany.Columns[5].HeaderStyle.Wrap = false;
                        gvCompany.Columns[6].HeaderStyle.Wrap = false;
                        gvCompany.Columns[7].HeaderStyle.Wrap = false;
                        gvCompany.Columns[8].HeaderStyle.Wrap = false;
                        gvCompany.Columns[9].HeaderStyle.Wrap = false;
                        gvCompany.Columns[10].HeaderStyle.Wrap = false;
                        gvCompany.Columns[11].HeaderStyle.Wrap = false;
                        gvCompany.Columns[12].HeaderStyle.Wrap = false;
                        gvCompany.Columns[13].HeaderStyle.Wrap = false;
                        gvCompany.Columns[14].HeaderStyle.Wrap = false;
                     
                    }

                }
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (ddSearch.Text == "Skills_Needed")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Skills_Needed like '%'+@Skills_Needed+'%' AND Approval='Approved' AND Status = 'Vacant'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Skills_Needed", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();

            }
            else if (ddSearch.Text == "Vacancy")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where Vacancy like '%'+@Vacancy+'%' AND Approval='Approved' AND Status = 'Vacant'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("Vacancy", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();


            }
            else if (ddSearch.Text == "City")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_companies where City like '%'+@City+'%' AND Approval='Approved' AND Status = 'Vacant'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("City", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvCompany.DataSource = sdt;
                gvCompany.DataBind();


            }
        }

        protected void gvCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            select();
        }
        public void select()
        {
            GridViewRow gr = gvCompany.SelectedRow;
            compname.Text = gr.Cells[3].Text;
            vacant.Text = gr.Cells[8].Text;
            address.Text = gr.Cells[4].Text;
            barangay.Text = gr.Cells[5].Text;
            city.Text = gr.Cells[6].Text;
            district.Text = gr.Cells[7].Text;
            quali1.Text = gr.Cells[10].Text;
            quali2.Text = gr.Cells[11].Text;
            quali3.Text = gr.Cells[12].Text;
            quali4.Text = gr.Cells[13].Text;
            quali5.Text = gr.Cells[14].Text;
            btncancel.Visible = true;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            compname.Text = "";
            vacant.Text = "";
            address.Text = "";
            barangay.Text = "";
            city.Text = "";
            district.Text = "";
            quali1.Text = "";
            quali2.Text = "";
            quali3.Text = "";
            quali4.Text = "";
            quali5.Text = "";
            btncancel.Visible = false;
        }
        
        
       

       
    }
}