﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class OnlineReserveRec_form : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected int widesData;
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();
            reserve();
            if (!IsPostBack)
            {
                Calendar3.Visible = false;
                ddyear2.Visible = false;
                ddmonth2.Visible = false;
                lblyear2.Visible = false;
                lblmonth2.Visible = false;

                DataSet years2 = new DataSet();
                years2.ReadXml(Server.MapPath("~/Year.xml"));

                ddyear2.DataTextField = "Number";
                ddyear2.DataTextField = "Number";

                ddyear2.DataSource = years2;
                ddyear2.DataBind();

                DataSet months2 = new DataSet();
                months2.ReadXml(Server.MapPath("~/Month.xml"));

                ddmonth2.DataTextField = "Name";
                ddmonth2.DataTextField = "Number";

                ddmonth2.DataSource = months2;
                ddmonth2.DataBind();
            }

        }
        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }

        public void access()
        {
            if (lblrole.Text == "Admin")
            {

            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }

        public void reserve()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_onlineapplicant ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvReserve.DataSource = dt;
            gvReserve.DataBind();
        }

        protected void gvReserve_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        // Row
                        gvReserve.Columns[0].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[1].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[2].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[3].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[4].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[5].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[6].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[7].ItemStyle.Width = widesData * 50;
                        gvReserve.Columns[8].ItemStyle.Width = widesData * 50;
               
                        



                        gvReserve.Columns[0].ItemStyle.Wrap = false;
                        gvReserve.Columns[1].ItemStyle.Wrap = false;
                        gvReserve.Columns[2].ItemStyle.Wrap = false;
                        gvReserve.Columns[3].ItemStyle.Wrap = false;
                        gvReserve.Columns[4].ItemStyle.Wrap = false;
                        gvReserve.Columns[5].ItemStyle.Wrap = false;
                        gvReserve.Columns[6].ItemStyle.Wrap = false;
                        gvReserve.Columns[7].ItemStyle.Wrap = false;
                        gvReserve.Columns[8].ItemStyle.Wrap = false;
                   
                        




                        //head

                        gvReserve.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvReserve.Columns[8].HeaderStyle.Width = widesData * 50;
                       
                       



                        gvReserve.Columns[0].HeaderStyle.Wrap = false;
                        gvReserve.Columns[1].HeaderStyle.Wrap = false;
                        gvReserve.Columns[2].HeaderStyle.Wrap = false;
                        gvReserve.Columns[3].HeaderStyle.Wrap = false;
                        gvReserve.Columns[4].HeaderStyle.Wrap = false;
                        gvReserve.Columns[5].HeaderStyle.Wrap = false;
                        gvReserve.Columns[6].HeaderStyle.Wrap = false;
                        gvReserve.Columns[7].HeaderStyle.Wrap = false;
                        gvReserve.Columns[8].HeaderStyle.Wrap = false;
              
                      


                    }

                }
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

        }

        protected void btninterview_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar3.Visible)
            {
                Calendar3.Visible = false;
                ddyear2.Visible = false;
                ddmonth2.Visible = false;
                lblyear2.Visible = false;
                lblmonth2.Visible = false;

                tbsched.Text = "";
            }
            else
            {
                Calendar3.Visible = true;
                ddyear2.Visible = true;
                ddmonth2.Visible = true;
                lblyear2.Visible = true;
                lblmonth2.Visible = true;
            }
        }

        protected void ddyear2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear2.SelectedValue);
            int month = Convert.ToInt16(ddmonth2.SelectedValue);

            Calendar3.VisibleDate = new DateTime(year, month, 1);
            Calendar3.SelectedDate = new DateTime(year, month, 1);
        }

        protected void ddmonth2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear2.SelectedValue);
            int month = Convert.ToInt16(ddmonth2.SelectedValue);

            Calendar3.VisibleDate = new DateTime(year, month, 1);
            Calendar3.SelectedDate = new DateTime(year, month, 1);
        }

        protected void Calendar3_SelectionChanged(object sender, EventArgs e)
        {
            tbsched.Text = Calendar3.SelectedDate.ToShortDateString();
            tbsched.Text = Calendar3.SelectedDate.ToString(" MMMM dd, yyyy");
            Calendar3.Visible = false;
            ddyear2.Visible = false;
            ddmonth2.Visible = false;
            lblyear2.Visible = false;
            lblmonth2.Visible = false;

        }

        protected void Calendar3_DayRender(object sender, DayRenderEventArgs e)
        {
            if (e.Day.IsWeekend)
            {

                e.Cell.Font.Strikeout = true;
                e.Day.IsSelectable = false;

            }
            if (e.Day.IsOtherMonth)
            {
                e.Day.IsSelectable = false;

            }
            DateTime pastday = e.Day.Date;
            DateTime date = DateTime.Now;
            int year = date.Year;
            int month = date.Month;
            int day = date.Day;
            DateTime today = new DateTime(year, month, day);
            if(pastday.CompareTo(today) < 0)
            {
                e.Cell.Font.Strikeout = true;
             
                e.Day.IsSelectable = false;

            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            update();
        }
        public void update()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {

                string query = "UPDATE tb_onlineapplicant SET  schedule_interview = @schedule_interview,time_interview = @time_interview where applicant_number = @applicant_number ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@applicant_number", lblid.Text);
                cmd.Parameters.AddWithValue("@schedule_interview", tbsched.Text);
                cmd.Parameters.AddWithValue("@time_interview", ddtime.Text);

                cmd.Connection.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    gvReserve.DataBind();
                    notify();
                    clear();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);

                }
            }
        }

        private void notify()
        {
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            NetworkCredential nc = new NetworkCredential();
            nc.UserName = "caloocanpeso21@gmail.com";
            nc.Password = "joloairagenachavez";
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = nc;
            smtp.Port = 587;
            smtp.EnableSsl = true;
            MailMessage msg = new MailMessage();
            msg.Subject = "PESO Interview";
            msg.Body = " Dear " + tbfname.Text + " " + tbmname.Text + ", " + tblname.Text + " Your Schedule and time of your Interview is  " + tbsched.Text + ", " + ddtime.Text + " \n\n\nThanks ";
            string toaddress = lblemail.Text;
            msg.To.Add(toaddress);
            string fromaddress = "caloocanpeso21@gmail.com";
            msg.From = new MailAddress(fromaddress);
            try
            {
                smtp.Send(msg);
            }
            catch
            {
                throw;
            }
        }
        public void enable()
        {
            tbfname.Enabled = true;
            tbmname.Enabled = true;
            tblname.Enabled = true;
            
            ddtime.Enabled = true;
           
        }
        public void disable()
        {
            tbfname.Enabled = false;
            tbmname.Enabled = false;
            tblname.Enabled = false;
            btnSave.Enabled = false;
            btnCancel.Enabled = false;
            ddtime.Enabled = false;

        }
        public void clear()
        {
            lblid.Text = "";
            tbfname.Text = "";
            tbmname.Text = "";
            tblname.Text = "";
            tbsched.Text = "";
            ddtime.Text = "Select Time";
            lblemail.Text = "";
        }
        protected void gvReserve_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            disable();
            clear();
            EditButton.Enabled = false;
            DeleteButton.Enabled = false;
           
        }

        protected void EditButton_Click(object sender, ImageClickEventArgs e)
        {
            enable();
        }

        protected void DeleteButton_Click(object sender, ImageClickEventArgs e)
        {
            
        }

        protected void gvReserve_SelectedIndexChanged1(object sender, EventArgs e)
        {
            GridViewRow gr2 = gvReserve.SelectedRow;
            lblid.Text = gr2.Cells[1].Text;
            tbfname.Text = gr2.Cells[2].Text;
            tbmname.Text = gr2.Cells[3].Text;
            tblname.Text = gr2.Cells[4].Text;
            lblemail.Text = gr2.Cells[5].Text;

            EditButton.Enabled = true;
            DeleteButton.Enabled = true;
            btnSave.Enabled = true;
            btnCancel.Enabled = true;
        }
    }
}