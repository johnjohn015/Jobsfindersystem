﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class Report : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected int widesData;
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();
            refrec();
        }
        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }

        public void access()
        {
            if (lblrole.Text == "Admin")
            {

            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }

        public void refrec()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_refer ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvReff.DataSource = dt;
            gvReff.DataBind();
        }

        protected void ddSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddrep.Text == "Monthly")
            {
                monthly.Visible = true;
                yearly.Visible = false;
                btnMonth.Visible = true;
                btnYear.Visible = false;
            }
            if(ddrep.Text=="Yearly")
            {
                monthly.Visible = false;
                yearly.Visible = true;
                btnYear.Visible = true;
                btnMonth.Visible = false;
            }
        }



        protected void gvReff_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void gvReff_RowDataBound2(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        //Row
                        gvReff.Columns[0].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[1].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[2].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[3].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[4].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[5].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[6].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[7].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[8].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[9].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[10].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[11].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[12].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[13].ItemStyle.Width = widesData * 50;








                        gvReff.Columns[0].ItemStyle.Wrap = false;
                        gvReff.Columns[1].ItemStyle.Wrap = false;
                        gvReff.Columns[2].ItemStyle.Wrap = false;
                        gvReff.Columns[3].ItemStyle.Wrap = false;
                        gvReff.Columns[4].ItemStyle.Wrap = false;
                        gvReff.Columns[5].ItemStyle.Wrap = false;
                        gvReff.Columns[6].ItemStyle.Wrap = false;
                        gvReff.Columns[7].ItemStyle.Wrap = false;
                        gvReff.Columns[8].ItemStyle.Wrap = false;
                        gvReff.Columns[9].ItemStyle.Wrap = false;
                        gvReff.Columns[10].ItemStyle.Wrap = false;
                        gvReff.Columns[11].ItemStyle.Wrap = false;
                        gvReff.Columns[12].ItemStyle.Wrap = false;
                        gvReff.Columns[13].ItemStyle.Wrap = false;







                        //Head
                        gvReff.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[8].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[9].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[10].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[11].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[12].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[13].HeaderStyle.Width = widesData * 50;

                        gvReff.Columns[0].FooterStyle.Width = widesData * 50;






                        gvReff.Columns[0].HeaderStyle.Wrap = false;
                        gvReff.Columns[1].HeaderStyle.Wrap = false;
                        gvReff.Columns[2].HeaderStyle.Wrap = false;
                        gvReff.Columns[3].HeaderStyle.Wrap = false;
                        gvReff.Columns[4].HeaderStyle.Wrap = false;
                        gvReff.Columns[5].HeaderStyle.Wrap = false;
                        gvReff.Columns[6].HeaderStyle.Wrap = false;
                        gvReff.Columns[7].HeaderStyle.Wrap = false;
                        gvReff.Columns[8].HeaderStyle.Wrap = false;
                        gvReff.Columns[9].HeaderStyle.Wrap = false;
                        gvReff.Columns[10].HeaderStyle.Wrap = false;
                        gvReff.Columns[11].HeaderStyle.Wrap = false;
                        gvReff.Columns[12].HeaderStyle.Wrap = false;
                        gvReff.Columns[13].HeaderStyle.Wrap = false;

                        //Footer
                        gvReff.Columns[0].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[1].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[2].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[3].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[4].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[5].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[6].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[7].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[8].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[9].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[10].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[11].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[12].FooterStyle.Width = widesData * 50;
                        gvReff.Columns[13].FooterStyle.Width = widesData * 50;








                        gvReff.Columns[0].FooterStyle.Wrap = false;
                        gvReff.Columns[1].FooterStyle.Wrap = false;
                        gvReff.Columns[2].FooterStyle.Wrap = false;
                        gvReff.Columns[3].FooterStyle.Wrap = false;
                        gvReff.Columns[4].FooterStyle.Wrap = false;
                        gvReff.Columns[5].FooterStyle.Wrap = false;
                        gvReff.Columns[6].FooterStyle.Wrap = false;
                        gvReff.Columns[7].FooterStyle.Wrap = false;
                        gvReff.Columns[8].FooterStyle.Wrap = false;
                        gvReff.Columns[9].FooterStyle.Wrap = false;
                        gvReff.Columns[10].FooterStyle.Wrap = false;
                        gvReff.Columns[11].FooterStyle.Wrap = false;
                        gvReff.Columns[12].FooterStyle.Wrap = false;
                        gvReff.Columns[13].FooterStyle.Wrap = false;



                    }

                }
            }

        }

      

        protected void btnMonth_Click(object sender, EventArgs e)
        {
            if (tbdates.Text == "dates")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where dates like '%'+@dates+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("dates", monthly.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }
        }

        protected void btnYear_Click(object sender, EventArgs e)
        {
            if (tbdates.Text == "dates")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where dates like '%'+@dates+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("dates", yearly.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            

        }

        protected void gvReff_DataBound(object sender, EventArgs e)
        {
            gvReff.FooterRow.Cells[0].Text = "Total Records: " + gvReff.Rows.Count.ToString();
        }
        }
    }
