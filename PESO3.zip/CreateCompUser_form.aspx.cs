﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class CreateCompUser_form : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        DataSet ds = new DataSet();
        SqlCommand com;
        string str;
        SqlCommand coms;
        string strs;
        static String activationcode;
         static String intentlink;
         static String comprofile;
         static String businesspermit;
         static String dtireg;
         static String birreg;
         static String dolereg;
         static String poeareg;
         static String notarized;
        static Int32 applicationid;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /*------------UPLOAD DOCS----------------------------*/

        private Boolean uploadletter()
        {
            Boolean intent = false;
            Boolean comprof = false;
            Boolean busiper = false;
            Boolean dti = false;
            Boolean bir = false;
            Boolean dole = false;
            Boolean poea = false;
            Boolean notary = false;



            if (FileUpload1.HasFile == true)
            {

                String contenttype = FileUpload1.PostedFile.ContentType;

                if (contenttype == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload1.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload1.SaveAs(Server.MapPath("~/letter intent/") + applicationid + ".pdf");

                    intentlink = "letter intent/" + applicationid + ".pdf";
                    intent = true;

                }
                
               
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload Letter of Intent in PDF Format Only');</script>");
                }

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }



             if (FileUpload2.HasFile == true)
            {

                String contenttype2 = FileUpload2.PostedFile.ContentType;

                if (contenttype2 == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload2.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload2.SaveAs(Server.MapPath("~/company profile/") + applicationid + ".pdf");

                    comprofile = "company profile/" + applicationid + ".pdf";
                    comprof = true;

                }



                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload Company Profile in PDF Format Only');</script>");
                }

            }
             else
             {
                 Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
             }


             if (FileUpload3.HasFile == true)
             {

                 String contenttype3 = FileUpload3.PostedFile.ContentType;

                 if (contenttype3 == "application/pdf")
                 {
                     int filesize;
                     filesize = FileUpload3.PostedFile.ContentLength;

                     getapplicationid();
                     FileUpload3.SaveAs(Server.MapPath("~/business permit/") + applicationid + ".pdf");

                     businesspermit = "business permit/" + applicationid + ".pdf";
                     busiper = true;

                 }



                 else
                 {
                     Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload Business Permit in PDF Format Only');</script>");
                 }

             }

             else
             {
                 Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
             }

             if (FileUpload4.HasFile == true)
             {

                 String contenttype4 = FileUpload4.PostedFile.ContentType;

                 if (contenttype4 == "application/pdf")
                 {
                     int filesize;
                     filesize = FileUpload4.PostedFile.ContentLength;

                     getapplicationid();
                     FileUpload4.SaveAs(Server.MapPath("~/dti registration/") + applicationid + ".pdf");

                     dtireg = "dti registration/" + applicationid + ".pdf";
                     dti = true;

                 }



                 else
                 {
                     Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload DTI Registration in PDF Format Only');</script>");
                 }

             }
             else
             {
                 Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
             }



             if (FileUpload5.HasFile == true)
             {

                 String contenttype5 = FileUpload5.PostedFile.ContentType;

                 if (contenttype5 == "application/pdf")
                 {
                     int filesize;
                     filesize = FileUpload5.PostedFile.ContentLength;

                     getapplicationid();
                     FileUpload5.SaveAs(Server.MapPath("~/bir registration/") + applicationid + ".pdf");

                     birreg = "bir registration/" + applicationid + ".pdf";
                     bir = true;

                 }



                 else
                 {
                     Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload BIR Registration in PDF Format Only');</script>");
                 }

             }

             else
             {
                 Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
             }



             if (FileUpload6.HasFile == true)
             {

                 String contenttype6 = FileUpload6.PostedFile.ContentType;

                 if (contenttype6 == "application/pdf")
                 {
                     int filesize;
                     filesize = FileUpload6.PostedFile.ContentLength;

                     getapplicationid();
                     FileUpload6.SaveAs(Server.MapPath("~/dole registration/") + applicationid + ".pdf");

                     dolereg = "dole registration/" + applicationid + ".pdf";
                     dole = true;

                 }



                 else
                 {
                     Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload DOLE Registration in PDF Format Only');</script>");
                 }

             }


             else
             {
                 Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
             }



             if (FileUpload7.HasFile == true)
             {

                 String contenttype7 = FileUpload7.PostedFile.ContentType;

                 if (contenttype7 == "application/pdf")
                 {
                     int filesize;
                     filesize = FileUpload7.PostedFile.ContentLength;

                     getapplicationid();
                     FileUpload7.SaveAs(Server.MapPath("~/poea registration/") + applicationid + ".pdf");

                     poeareg = "poea registration/" + applicationid + ".pdf";
                     poea = true;

                 }




                 else
                 {
                     Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload POEA Registration in PDF Format Only');</script>");
                 }

             }

             else
             {
                 Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
             }

             if (FileUpload8.HasFile == true)
             {

                 String contenttype8 = FileUpload8.PostedFile.ContentType;

                 if (contenttype8 == "application/pdf")
                 {
                     int filesize;
                     filesize = FileUpload8.PostedFile.ContentLength;

                     getapplicationid();
                     FileUpload8.SaveAs(Server.MapPath("~/notarized/") + applicationid + ".pdf");

                     notarized = "notarized/" + applicationid + ".pdf";
                     notary = true;

                 }



                 else
                 {
                     Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload Notarized in PDF Format Only');</script>");
                 }

             }





            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }


            return intent;
            return comprof;
            return busiper;
            return dti;
            return bir;
            return dole;
            return poea;
            return notary;
        }
        public void getapplicationid()
        {

            String myquery = "select company_id from tb_companyuser";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = myquery;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count < 1)
            {
                applicationid = 10001;

            }
            else
            {




                String myquery1 = "select max(company_id) from tb_companyuser";
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandText = myquery1;
                cmd1.Connection = con;
                SqlDataAdapter da1 = new SqlDataAdapter();
                da1.SelectCommand = cmd1;
                DataSet ds1 = new DataSet();
                da1.Fill(ds1);
                applicationid = Convert.ToInt32(ds1.Tables[0].Rows[0][0].ToString());
                applicationid = applicationid + 1;
                con.Close();
            }

        }
         


















        public void clear()
        {
            tbcompname.Text = "";
            tbheadname.Text = "";
            tbposition.Text = "";
            tbdepartment.Text = "";
            tbaddress.Text = "";
            tbbarangay.Text = "";
            tbcity.Text = "";
            tbdistrict.Text = "";
            tbemail.Text = "";
            tbpassword.Text = "";
            tbconfirm.Text = "";
        }
        private void sendcode()
        {
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential("caloocanpeso21@gmail.com","joloairagenachavez");
            smtp.EnableSsl = true;
            MailMessage msg = new MailMessage();
            msg.Subject = "Activation Code to Verify Email Address";
            msg.Body = "Dear " + tbcompname.Text + ", Your Activation Code is " + activationcode + " \n\n\nThanks ";
            string toaddress = tbemail.Text;
            msg.To.Add(toaddress);
            string fromaddress = "caloocanpeso21@gmail.com";
            msg.From = new MailAddress(fromaddress);
            try
            {
                smtp.Send(msg);
            }
            catch
            {
                throw;
            }
        }

        public void submit()
        {
            SqlConnection cons1 = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
            cons1.Open();
            str = "select count(*)from tb_companyuser where email='" + tbemail.Text + "'";
            com = new SqlCommand(str, cons1);
            int count1 = Convert.ToInt32(com.ExecuteScalar());
            if (count1 > 0)
            {

                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Already Use Email.');</script>");
                ds.Clear();

            }
            else
            {

                if (uploadletter() == true)
                {
                    Random random = new Random();
                    activationcode = random.Next(1001, 9999).ToString();
                    String query = "insert into tb_companyuser values('" + tbcompname.Text + "','" + tbheadname.Text + "','" + tbposition.Text + "','" + tbdepartment.Text + "','" + tbaddress.Text + "','" + tbbarangay.Text + "','" + tbcity.Text + "','" + tbdistrict.Text + "','" + tbpassword.Text + "','" + tbconfirm.Text + "','deactivate','" + tbemail.Text + "','" + activationcode + "','" + intentlink + "','" + comprofile + "','" + businesspermit + "','" + dtireg + "','" + birreg + "','" + dolereg + "','" + poeareg + "','" + notarized + "','Not Complete')";
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = query;
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    sendcode();
                    Response.Redirect("create-user.aspx?emailadd=" + tbemail.Text);
                    

                }
            }

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (tbpassword.Text != tbconfirm.Text)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Password and Confirm Password not MATCH');</script>");
            }
            else if (tbcompname.Text == "" || tbheadname.Text == "" || tbposition.Text == "" || tbdepartment.Text == "" || tbaddress.Text == "" || tbemail.Text == "" || tbpassword.Text == "" || tbconfirm.Text == "" || tbcity.Text == "")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Please Fill up Empty Field');</script>");
                val1.Visible = true;
                val2.Visible = true;
                val3.Visible = true;
                val4.Visible = true;
                val5.Visible = true;
                val6.Visible = true;
                val7.Visible = true;
                val8.Visible = true;
            }
            else
            {
                submit();
            }
        }
    }
}