﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.Security;
namespace PESO3
{
    public partial class login_applicant : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        SqlCommand cmd;
        SqlDataReader reader;
        DataSet ds = new DataSet();
        SqlCommand com;
        string str;
        int i;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void Login()
        {
            using (SqlConnection sqlcon = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {
                sqlcon.Open();
                string query = "Select Count (1) from tb_onlineapplicant where username=@username AND password=@password";
                SqlCommand sqlcmd = new SqlCommand(query, sqlcon);
                sqlcmd.Parameters.AddWithValue("@username", tbUser.Text.Trim());
                sqlcmd.Parameters.AddWithValue("@password", tbPass.Text.Trim());
                int count = Convert.ToInt32(sqlcmd.ExecuteScalar());
                if (count == 1)
                {

                    Session["username"] = tbUser.Text.Trim();
                    Session["applicant_number"] = lblid.Text.Trim();
                    //applicantinfo
                    Session["skills"] = skills.Text.Trim();
                    Session["fname"] = fname.Text.Trim();
                    Session["mname"] = mname.Text.Trim();
                    Session["lname"] = lname.Text.Trim();
                    Session["address"] = address.Text.Trim();
                    Session["brgy"] = brgy.Text.Trim();
                    Session["city"] = city.Text.Trim();
                    Session["district"] = district.Text.Trim();
                    Session["dob"] = bdate.Text.Trim();
                    Session["age"] = age.Text.Trim();
                    Session["gender"] = gender.Text.Trim();
                    Session["email"] = email.Text.Trim();
                    Session["schedule_interview"] = date.Text.Trim();
                    Session["time_interview"] = time.Text.Trim();
                    Session["username"] = tbUser.Text.Trim();
                    Session["password"] = password.Text.Trim();
                    Session["confirmpass"] = confirm.Text.Trim();
                    Session["others"] = others.Text.Trim();
                    Response.Redirect("panel-applicant.aspx");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Login Succesfull');</script>");
                }
                else
                {
                    statuss();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('You have Entered Invalid Username or Password!!!');</script>");
                }









            }
        }

        public void statuss()
        {
            con.Open();

            str = "select applicant_number,status,skills,others,fname,mname,lname,address,brgy,city,district,dob,age,gender,email,username,password,confirmpass,schedule_interview,time_interview from tb_onlineapplicant where username='" + tbUser.Text + "'";
            com = new SqlCommand(str, con);
            SqlDataReader reader = com.ExecuteReader();

            reader.Read();
            status.Text = reader["status"].ToString();
            lblid.Text = reader["applicant_number"].ToString();
            date.Text = reader["schedule_interview"].ToString();
            time.Text = reader["time_interview"].ToString();
            //applicant info
            skills.Text = reader["skills"].ToString();
            fname.Text = reader["fname"].ToString();
            mname.Text = reader["mname"].ToString();
            lname.Text = reader["lname"].ToString();
            address.Text = reader["address"].ToString();
            brgy.Text = reader["brgy"].ToString();
            city.Text = reader["city"].ToString();
            district.Text = reader["district"].ToString();
            bdate.Text = reader["dob"].ToString();
            age.Text = reader["age"].ToString();
            gender.Text = reader["gender"].ToString();
            email.Text = reader["email"].ToString();
            tbUser.Text = reader["username"].ToString();
            password.Text = reader["password"].ToString();
            confirm.Text = reader["confirmpass"].ToString();

            reader.Close();
            con.Close();
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            statuss();

            if (status.Text == "disapproved")
            {
                Response.Redirect("appNotActive.aspx");
                // Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Your Account is not Activated');</script>");
            }
            else
            {
                Login();
            }
        }
    }
}