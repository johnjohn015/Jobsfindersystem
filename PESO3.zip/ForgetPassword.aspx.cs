﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Net;
using System.Net.Mail;

namespace PESO3
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
              SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
            string sqlquery = "Select username,password from tb_users where email=@email";
            SqlCommand cmd = new SqlCommand(sqlquery, con);
            cmd.Parameters.AddWithValue("@email", tbemail.Text);
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            if(sdr.Read())
            {
                
                string username = sdr["username"].ToString();
                string password = sdr["password"].ToString();
                
                MailMessage mm = new MailMessage("caloocanpeso21@gmail.com",tbemail.Text);
                mm.Subject = "Your Password !";
                mm.Body = string.Format("Hello :<h1>{0}</h1> is your Email id <br/> your Password is<h1>{1}</h1>", username, password);
                mm.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                NetworkCredential nc = new NetworkCredential();
                nc.UserName = "caloocanpeso21@gmail.com";
                nc.Password = "joloairagenachavez";
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = nc;
                smtp.Port = 587;
                smtp.Send(mm);
                labmsg.Text = "Your Password has been sent to" + tbemail.Text;
                labmsg.ForeColor = Color.Green;
            }
                else
                {
                labmsg.Text = tbemail.Text +" - This Email Is Not Exists"; 
                labmsg.ForeColor = Color.Red;
                }

            }   }
    }
