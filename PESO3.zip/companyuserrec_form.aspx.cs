﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PESO3
{
    public partial class companyuserrec_form : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected int widesData;
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();
            accounts();
        }
        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }

        public void access()
        {
            if (lblrole.Text == "Admin")
            {

            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }


        public void accounts()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_companyuser ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvCompAccounts.DataSource = dt;
            gvCompAccounts.DataBind();
        }

        public void clear()
        {
            tbcompname.Text = "";
            tbheadname.Text = "";
            tbposition.Text = "";
            tbdepartment.Text = "";
            tbaddress.Text = "";
            tbbarangay.Text = "";
            tbcity.Text = "";
            tbdistrict.Text = "";
            
            tbpassword.Text = "";
            tbconfirm.Text = "";
            ddstatus.Text = "";

        }

        public void disable()
        {
            tbcompname.Enabled = false;
            tbheadname.Enabled = false;
            tbposition.Enabled = false;
            tbdepartment.Enabled = false;
            tbaddress.Enabled = false;
            tbbarangay.Enabled = false;
            tbcity.Enabled = false;
            tbdistrict.Enabled = false;
            
            tbpassword.Enabled = false;
            tbconfirm.Enabled = false;
            EditButton.Enabled = false;
            DeleteButton.Enabled = false;
            ddstatus.Enabled = false;
            btnSave.Enabled = false;
            btnCancel.Enabled = false;

        }
        public void enable()
        {
            tbcompname.Enabled = true;
            tbheadname.Enabled = true;
            tbposition.Enabled = true;
            tbdepartment.Enabled = true;
            tbaddress.Enabled = true;
            tbbarangay.Enabled = true;
            tbcity.Enabled = true;
            tbdistrict.Enabled = true;
            
            tbpassword.Enabled = true;
            tbconfirm.Enabled = true;
            EditButton.Enabled = true;
            DeleteButton.Enabled = true;
            ddstatus.Enabled = true;
            btnSave.Enabled = true;
        }

        public void updatedata()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {

                string query = "UPDATE tb_companyuser SET company_name = @company_name, head_name = @head_name, position = @position, department = @department, address = @address, brgy = @brgy, town_city = @town_city, district = @district, password = @password, confirmpassword = @confirmpassword, requirements = @requirements where company_id = @company_id ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@company_id", tbid.Text);
                cmd.Parameters.AddWithValue("@company_name", tbcompname.Text);
                cmd.Parameters.AddWithValue("@head_name", tbheadname.Text);
                cmd.Parameters.AddWithValue("@position", tbposition.Text);
                cmd.Parameters.AddWithValue("@department", tbdepartment.Text);
                cmd.Parameters.AddWithValue("@address", tbaddress.Text);
                cmd.Parameters.AddWithValue("@brgy", tbbarangay.Text);
                cmd.Parameters.AddWithValue("@town_city", tbcity.Text);
                cmd.Parameters.AddWithValue("@district", tbdistrict.Text);
                
                cmd.Parameters.AddWithValue("@password", tbpassword.Text);
                cmd.Parameters.AddWithValue("@confirmpassword", tbconfirm.Text);
                cmd.Parameters.AddWithValue("@requirements", ddstatus.Text);


                cmd.Connection.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    gvCompAccounts.DataBind();

                    clear();
                    disable();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);

                }
            }
        }

        protected void gvCompAccounts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        //Row
                        gvCompAccounts.Columns[0].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[1].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[2].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[3].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[4].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[5].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[6].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[7].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[8].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[9].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[10].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[11].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[12].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[13].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[14].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[15].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[16].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[17].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[18].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[19].ItemStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[20].ItemStyle.Width = widesData * 50;







                        gvCompAccounts.Columns[0].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[1].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[2].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[3].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[4].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[5].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[6].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[7].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[8].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[9].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[10].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[11].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[12].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[13].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[14].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[15].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[16].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[17].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[18].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[19].ItemStyle.Wrap = false;
                        gvCompAccounts.Columns[20].ItemStyle.Wrap = false;


                        //Head
                        gvCompAccounts.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[8].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[9].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[10].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[11].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[12].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[13].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[14].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[15].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[16].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[17].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[18].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[19].HeaderStyle.Width = widesData * 50;
                        gvCompAccounts.Columns[20].HeaderStyle.Width = widesData * 50;






                        gvCompAccounts.Columns[0].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[1].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[2].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[3].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[4].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[5].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[6].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[7].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[8].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[9].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[9].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[10].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[11].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[12].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[13].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[14].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[15].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[16].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[17].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[18].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[19].HeaderStyle.Wrap = false;
                        gvCompAccounts.Columns[20].HeaderStyle.Wrap = false;



                    }
                }
            }
        }

        protected void gvCompAccounts_PreRender(object sender, EventArgs e)
        {
            foreach (GridViewRow row in gvCompAccounts.Rows)
            {

                string pwd = new string('*', row.Cells[10].Text.Length);
                string pwd2 = new string('*', row.Cells[11].Text.Length);

                row.Cells[10].Text = pwd;
                row.Cells[11].Text = pwd2;

            }
        }

        protected void gvCompAccounts_SelectedIndexChanged1(object sender, EventArgs e)
        {
            GridViewRow gr = gvCompAccounts.SelectedRow;
            tbid.Text = gr.Cells[1].Text;
            tbcompname.Text = gr.Cells[2].Text;
            tbheadname.Text = gr.Cells[3].Text;
            tbposition.Text = gr.Cells[4].Text;
            tbdepartment.Text = gr.Cells[5].Text;
            tbaddress.Text = gr.Cells[6].Text;
            tbbarangay.Text = gr.Cells[7].Text;
            tbcity.Text = gr.Cells[8].Text;
            tbdistrict.Text = gr.Cells[9].Text;
            tbpassword.Text = gr.Cells[10].Text;
            tbconfirm.Text = gr.Cells[11].Text;
            
            ddstatus.Text = gr.Cells[21].Text;
            
            btnCancel.Enabled = true;
            EditButton.Enabled = true;
            DeleteButton.Enabled = true;
        }

        protected void EditButton_Click(object sender, ImageClickEventArgs e)
        {
            enable();
        }

        protected void DeleteButton_Click(object sender, ImageClickEventArgs e)
        {

            delete();
        }
        public void delete()
        {
            con.Open();
            using (SqlCommand com = new SqlCommand("DELETE FROM tb_companyuser WHERE company_id=@company_id", con))
            {
                com.Parameters.AddWithValue("@company_id", tbid.Text);
                com.ExecuteNonQuery();
                gvCompAccounts.DataBind();
                clear();
                disable();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            updatedata();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

        }
    }
}