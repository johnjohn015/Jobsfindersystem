﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PESO3
{
    public partial class Apprec_form : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        DataSet ds = new DataSet();
        SqlCommand com;
        string str;
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();
            DateTime date = System.DateTime.Today.Date;
            dates.Text = String.Format("{0:MMMM dd, yyyy}", date);
            
            widesData = 0;
            applicant();
             // company();
        }

        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }

        public void access()
        {
            if (lblrole.Text == "Admin")
            {

            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }

        public void applicant()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_applicants ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvApplicant.DataSource = dt;
            gvApplicant.DataBind();
        }
        public void company()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_companies ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvCompany.DataSource = dt;
            gvCompany.DataBind();
        }



        protected void gvApplicant_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = gvApplicant.SelectedRow;
            tbSorting.Text = gr.Cells[10].Text;
            tbOtherSort.Text = gr.Cells[11].Text;
            btnSort.Enabled = true;
        }


        protected void gvCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            /* //Applicant
             {
                 GridViewRow gr = gvApplicant.SelectedRow;
                 Response.Redirect("Reffer_form.aspx?fname=" + gr.Cells[1].Text + "&mname=" + gr.Cells[2].Text + "&lname=" + gr.Cells[3].Text + "&address=" + gr.Cells[4].Text + "&brgy=" + gr.Cells[5].Text + "&city=" + gr.Cells[6].Text + "&district=" + gr.Cells[7].Text + "&gender=" + gr.Cells[8].Text + "&age=" + gr.Cells[9].Text + "&skills_experience=" + gr.Cells[10].Text + "&educational_attain=" + gr.Cells[11].Text + "&position_applied_for=" + gr.Cells[12].Text);
             }
             {
                 GridViewRow gr2 = gvCompany.SelectedRow;
                 Response.Redirect("Reffer_form.aspx?Head_Name=" + gr2.Cells[1].Text + "&Position=" + gr2.Cells[2].Text);
             }
             */
            GridViewRow gr = gvApplicant.SelectedRow;
            GridViewRow gr2 = gvCompany.SelectedRow;
            //Applicant
            lbfname.Text = gr.Cells[3].Text;
            lbmname.Text = gr.Cells[4].Text;
            lblname.Text = gr.Cells[5].Text;
          
            lbGender.Text = gr.Cells[7].Text;
            lbAge.Text = gr.Cells[6].Text;
            lbSkills.Text = gr.Cells[10].Text;
            lblemail.Text = gr.Cells[8].Text;
            lbEduc.Text = gr.Cells[9].Text;
            lbposition.Text = gr.Cells[1].Text;
            lbOtherSkills.Text = gr.Cells[11].Text;


            //Company
            lbhname.Text = gr2.Cells[4].Text;
            lbCompOtherSkills.Text = gr2.Cells[2].Text;
            lbcposition.Text = gr2.Cells[5].Text;
            lbdepartment.Text = gr2.Cells[6].Text;
            lbcompname.Text = gr2.Cells[7].Text;
            lbcaddress.Text = gr2.Cells[8].Text;
            lbcbrgy.Text = gr2.Cells[9].Text;
            lbccity.Text = gr2.Cells[10].Text;
            lbcdistrict.Text = gr2.Cells[11].Text;
            lbvacancy.Text = gr2.Cells[12].Text;
            lbskillsneed.Text = gr2.Cells[1].Text;
            lbstatus.Text = gr2.Cells[13].Text;
            tbQuali1.Text = gr2.Cells[14].Text;
            tbQuali2.Text = gr2.Cells[15].Text;
            tbQuali3.Text = gr2.Cells[16].Text;
            tbQuali4.Text = gr2.Cells[17].Text;
            tbQuali5.Text = gr2.Cells[18].Text;
        
        }
        protected int widesData;
        protected void gvCompany_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        //Row
                        gvCompany.Columns[0].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[1].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[2].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[3].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[4].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[5].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[6].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[7].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[8].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[9].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[10].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[11].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[12].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[13].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[14].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[15].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[16].ItemStyle.Width = widesData * 50;
                        gvCompany.Columns[17].ItemStyle.Width = widesData * 50;
                        


                        gvCompany.Columns[0].ItemStyle.Wrap = false;
                        gvCompany.Columns[1].ItemStyle.Wrap = false;
                        gvCompany.Columns[2].ItemStyle.Wrap = false;
                        gvCompany.Columns[3].ItemStyle.Wrap = false;
                        gvCompany.Columns[4].ItemStyle.Wrap = false;
                        gvCompany.Columns[5].ItemStyle.Wrap = false;
                        gvCompany.Columns[6].ItemStyle.Wrap = false;
                        gvCompany.Columns[7].ItemStyle.Wrap = false;
                        gvCompany.Columns[8].ItemStyle.Wrap = false;
                        gvCompany.Columns[9].ItemStyle.Wrap = false;
                        gvCompany.Columns[10].ItemStyle.Wrap = false;
                        gvCompany.Columns[11].ItemStyle.Wrap = false;
                        gvCompany.Columns[12].ItemStyle.Wrap = false;
                        gvCompany.Columns[13].ItemStyle.Wrap = false;
                        gvCompany.Columns[14].ItemStyle.Wrap = false;
                        gvCompany.Columns[15].ItemStyle.Wrap = false;
                        gvCompany.Columns[16].ItemStyle.Wrap = false;
                        gvCompany.Columns[17].ItemStyle.Wrap = false;
                        
                        //Head
                        gvCompany.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[8].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[9].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[10].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[11].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[12].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[13].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[14].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[15].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[16].HeaderStyle.Width = widesData * 50;
                        gvCompany.Columns[17].HeaderStyle.Width = widesData * 50;
                        


                        gvCompany.Columns[0].HeaderStyle.Wrap = false;
                        gvCompany.Columns[1].HeaderStyle.Wrap = false;
                        gvCompany.Columns[2].HeaderStyle.Wrap = false;
                        gvCompany.Columns[3].HeaderStyle.Wrap = false;
                        gvCompany.Columns[4].HeaderStyle.Wrap = false;
                        gvCompany.Columns[5].HeaderStyle.Wrap = false;
                        gvCompany.Columns[6].HeaderStyle.Wrap = false;
                        gvCompany.Columns[7].HeaderStyle.Wrap = false;
                        gvCompany.Columns[8].HeaderStyle.Wrap = false;
                        gvCompany.Columns[9].HeaderStyle.Wrap = false;
                        gvCompany.Columns[10].HeaderStyle.Wrap = false;
                        gvCompany.Columns[11].HeaderStyle.Wrap = false;
                        gvCompany.Columns[12].HeaderStyle.Wrap = false;
                        gvCompany.Columns[13].HeaderStyle.Wrap = false;
                        gvCompany.Columns[14].HeaderStyle.Wrap = false;
                        gvCompany.Columns[15].HeaderStyle.Wrap = false;
                        gvCompany.Columns[16].HeaderStyle.Wrap = false;
                        gvCompany.Columns[17].HeaderStyle.Wrap = false;
                        
                    }

                }
            }
        }
        protected int widestdata;
        protected void gvApplicant_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widestdata)
                    {
                        widestdata = catNameLen;
                        // Row
                        gvApplicant.Columns[0].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[1].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[2].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[3].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[4].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[5].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[6].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[7].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[8].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[9].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[10].ItemStyle.Width = widestdata * 50;
                        gvApplicant.Columns[11].ItemStyle.Width = widestdata * 50;
                      


                        gvApplicant.Columns[0].ItemStyle.Wrap = false;
                        gvApplicant.Columns[1].ItemStyle.Wrap = false;
                        gvApplicant.Columns[2].ItemStyle.Wrap = false;
                        gvApplicant.Columns[3].ItemStyle.Wrap = false;
                        gvApplicant.Columns[4].ItemStyle.Wrap = false;
                        gvApplicant.Columns[5].ItemStyle.Wrap = false;
                        gvApplicant.Columns[6].ItemStyle.Wrap = false;
                        gvApplicant.Columns[7].ItemStyle.Wrap = false;
                        gvApplicant.Columns[8].ItemStyle.Wrap = false;
                        gvApplicant.Columns[9].ItemStyle.Wrap = false;
                        gvApplicant.Columns[10].ItemStyle.Wrap = false;
                        gvApplicant.Columns[11].ItemStyle.Wrap = false;
                      


                        //head

                        gvApplicant.Columns[0].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[1].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[2].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[3].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[4].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[5].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[6].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[7].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[8].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[9].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[10].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[11].HeaderStyle.Wrap = false;
                


                        gvApplicant.Columns[0].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[1].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[2].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[3].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[4].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[5].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[6].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[7].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[8].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[9].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[10].HeaderStyle.Wrap = false;
                        gvApplicant.Columns[11].HeaderStyle.Wrap = false;
       


                    }

                }
            }
        }

        public SqlCommand cmd { get; set; }

        protected void tbSort_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnSort_Click(object sender, EventArgs e)
        {
            
            con.Open();
            SqlCommand cmd = new SqlCommand();
            string sqlquery = "select * from tb_companies where Skills_Needed like '%'+@Skills_Needed+'%' AND Approval='Approved'";
            cmd.CommandText = sqlquery;
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("Skills_Needed", tbSorting.Text);
            DataTable sdt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(sdt);
            gvCompany.DataSource = sdt;
            gvCompany.DataBind();
           
        }
        

        protected void tbQuali3_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Apprec_form.aspx");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (lbstatus.Text == "No Vacancy")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('No Vacant');</script>");
            }
            else
            {
                refer();
            }
           
           
        }

        public void referal()
        {
            //date
            Session["date"] = dates.Text;

            //head name and address of company
            Session["headname"] = lbhname.Text;
            Session["positon"] = lbcposition.Text;
            Session["dept"] = lbdepartment.Text;
            Session["company"] = lbcompname.Text;
            Session["address"] = lbcaddress.Text;
            Session["barangay"] = lbcbrgy.Text;
            Session["city"] = lbccity.Text;
            Session["district"] = lbcdistrict.Text;


            //Applicant Name,Address,and company Vacancy
            Session["fname"] = lbfname.Text;
            Session["mname"] = lbmname.Text;
            Session["lname"] = lblname.Text;
            Session["vacancy"] = lbvacancy.Text;
            
            Response.Redirect("sampleprint.aspx");
        }

        public void clear()
        {
            //Applicant
            lbfname.Text = "";
            lbmname.Text = "";
            lblname.Text = "";
           
            lbGender.Text = "";
            lbAge.Text = "";
            lbSkills.Text = "";
            lbEduc.Text = "";
            lbposition.Text = "";

            //Company
            lbhname.Text = "";
            lbcposition.Text = "";
            lbdepartment.Text = "";
            lbcompname.Text = "";
            lbcaddress.Text = "";
            lbcbrgy.Text = "";
            lbccity.Text = "";
            lbcdistrict.Text = "";
            lbvacancy.Text = "";
            lbskillsneed.Text = "";
            lbstatus.Text = "";
            tbQuali1.Text = "";
            tbQuali2.Text = "";
            tbQuali3.Text = "";
            tbQuali4.Text = "";
            tbQuali5.Text = "";
        }

        protected void btnrefCancel_Click(object sender, EventArgs e)
        {
            redirect();
        }

        public void redirect()
        {
            clear();
            Response.Redirect("Apprec_form.aspx");
        }

        public void refer()
        {

          /*  SqlConnection cons = new SqlConnection(@"Data Source=(local)\SQLSERVERNEW;Initial Catalog=db_eis;Integrated Security=true;");
            cons.Open();
            str = "select count(*) from tb_refer where comp_vacancy='" + lbvacancy.Text + "'";
            com = new SqlCommand(str, cons);
            int count = Convert.ToInt32(com.ExecuteScalar());
            if (count > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Already Refer');</script>");
                ds.Clear();

            }
            else
            {*/
              con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_refer values('" + lbfname.Text + "','" + lbmname.Text + "','" + lblname.Text + "','" + lbGender.Text + "','" + lbAge.Text + "','" + lbSkills.Text + "','" + lbEduc.Text + "','" + lbposition.Text + "','" + lbhname.Text + "','" + lbcposition.Text + "','" + lbdepartment.Text + "','" + lbcompname.Text + "','" + lbcaddress.Text + "','" + lbcbrgy.Text + "','" + lbccity.Text + "','" + lbcdistrict.Text + "','" + lbvacancy.Text + "','" + lbskillsneed.Text + "','" + lbstatus.Text + "','" + tbQuali1.Text + "','" + tbQuali2.Text + "','" + tbQuali3.Text + "','" + tbQuali4.Text + "','" + tbQuali5.Text + "','" + dates.Text + "','Reffered','" + lblemail.Text + "','" + lbOtherSkills.Text + "','" + lbCompOtherSkills.Text + "','remarks')";
            cmd.ExecuteNonQuery();
            con.Close();
            //    Button2.Visible = true;
           //     btnSave.Visible = false;
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Applicant Registered');</script>");
                referal();
              
            //}
        }

        protected void btnothersort_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand();
            string sqlquery = "select * from tb_companies where other_work_skills like '%'+@other_work_skills+'%' AND Approval='Approved'";
            cmd.CommandText = sqlquery;
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("other_work_skills", tbOtherSort.Text);
            DataTable sdt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(sdt);
            gvCompany.DataSource = sdt;
            gvCompany.DataBind();
        }

            
        
    }
}