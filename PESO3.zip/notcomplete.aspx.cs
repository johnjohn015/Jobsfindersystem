﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class notcomplete : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        DataSet ds = new DataSet();
        SqlCommand com;
        string str;
        SqlCommand coms;
        string strs;
        static String activationcode;
        static String intentlink;
        static String comprofile;
        static String businesspermit;
        static String dtireg;
        static String birreg;
        static String dolereg;
        static String poeareg;
        static String notarized;
        static Int32 applicationid;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblcompemail.Text = "" + Session["email"];
            lblposition.Text = "" + Session["position"];
            lblhead.Text = "" + Session["head_name"];
            lblcompname.Text = "" + Session["company_name"];
            lbldept.Text = "" + Session["department"];
            address.Text = Session["address"].ToString();
            barangay.Text = Session["brgy"].ToString();
            city.Text = Session["town_city"].ToString();
            district.Text = Session["district"].ToString();
            require.Text = Session["requirements"].ToString();


            //fileupdload
            require.Text = "" + Session["requirements"];
            compid.Text = "" + Session["company_id"];
            intent.Text = "" + Session["letterofintent"];
            comprof.Text = "" + Session["companyprofile"];
            businessper.Text = "" + Session["businesspermit"];
            dti.Text = "" + Session["dti"];
            bir.Text = "" + Session["bir"];
            dole.Text = "" + Session["dole"];
            poea.Text = "" + Session["poea"];
            nota.Text = "" + Session["notarized"];
            require.Text = "" + Session["requirements"];





            Session["email"] = lblemail.Text.Trim();
            Session["company_name"] = lblcompname.Text.Trim();
            Session["department"] = lbldept.Text.Trim();
            Session["position"] = lblposition.Text.Trim();
            Session["head_name"] = lblhead.Text.Trim();
            Session["address"] = address.Text.Trim();
            Session["brgy"] = barangay.Text.Trim();
            Session["town_city"] = city.Text.Trim();
            Session["district"] = district.Text.Trim();
            //-------------fileupload
            Session["letterofintent"] = intent.Text.Trim();
            Session["companyprofile"] = comprof.Text.Trim();
            Session["businesspermit"] = businessper.Text.Trim();
            Session["dti"] = dti.Text.Trim();
            Session["bir"] = bir.Text.Trim();
            Session["dole"] = dole.Text.Trim();
            Session["poea"] = poea.Text.Trim();
            Session["notarized"] = nota.Text.Trim();
            Session["company_id"] = compid.Text.Trim();
            Session["requirements"] = require.Text.Trim();

            lettintent();
            comprofiles();
            businesspermits();
            dtireq();
            birreq();
            dolereq();
            poeareq();
            notarizeds();
            requirecomplete();

            
            

            
        }

        public void requirecomplete()
        {
            if (require.Text == "Not Complete")
            {
                hlreq.Visible = true;
            }
            else if (require.Text == "Complete")
            {
                hlreq.Visible = false;
            }
        }


        /*------------UPLOAD DOCS----------------------------*/

        private Boolean uploadletter()
        {
            Boolean intent = true;
            Boolean comprofss = true;
            Boolean busiper = true;
            Boolean dti = true;
            Boolean bir = true;
            Boolean dole = true;
            Boolean poea = true;
            Boolean notary = true;



            if (FileUpload1.HasFile == true)
            {

                String contenttype = FileUpload1.PostedFile.ContentType;

                if (contenttype == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload1.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload1.SaveAs(Server.MapPath("~/letter intent/") + applicationid + ".pdf");
                   
                    intentlink = "letter intent/" + applicationid + ".pdf";
                    intent = true;

                }


                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload Letter of Intent in PDF Format Only');</script>");
                }

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }



            if (FileUpload2.HasFile == true)
            {

                String contenttype2 = FileUpload2.PostedFile.ContentType;

                if (contenttype2 == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload2.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload2.SaveAs(Server.MapPath("~/company profile/") + applicationid + ".pdf");
                    
                    comprofile = "company profile/" + applicationid + ".pdf";
                    comprofss = true;

                }



                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload Company Profile in PDF Format Only');</script>");
                }

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }


            if (FileUpload3.HasFile == true)
            {

                String contenttype3 = FileUpload3.PostedFile.ContentType;

                if (contenttype3 == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload3.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload3.SaveAs(Server.MapPath("~/business permit/") + applicationid + ".pdf");

                    businesspermit = "business permit/" + applicationid + ".pdf";
                    busiper = true;

                }



                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload Business Permit in PDF Format Only');</script>");
                }

            }

            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }

            if (FileUpload4.HasFile == true)
            {

                String contenttype4 = FileUpload4.PostedFile.ContentType;

                if (contenttype4 == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload4.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload4.SaveAs(Server.MapPath("~/dti registration/") + applicationid + ".pdf");

                    dtireg = "dti registration/" + applicationid + ".pdf";
                    dti = true;

                }



                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload DTI Registration in PDF Format Only');</script>");
                }

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }



            if (FileUpload5.HasFile == true)
            {

                String contenttype5 = FileUpload5.PostedFile.ContentType;

                if (contenttype5 == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload5.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload5.SaveAs(Server.MapPath("~/bir registration/") + applicationid + ".pdf");

                    birreg = "bir registration/" + applicationid + ".pdf";
                    bir = true;

                }



                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload BIR Registration in PDF Format Only');</script>");
                }

            }

            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }



            if (FileUpload6.HasFile == true)
            {

                String contenttype6 = FileUpload6.PostedFile.ContentType;

                if (contenttype6 == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload6.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload6.SaveAs(Server.MapPath("~/dole registration/") + applicationid + ".pdf");

                    dolereg = "dole registration/" + applicationid + ".pdf";
                    dole = true;

                }



                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload DOLE Registration in PDF Format Only');</script>");
                }

            }


            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }



            if (FileUpload7.HasFile == true)
            {

                String contenttype7 = FileUpload7.PostedFile.ContentType;

                if (contenttype7 == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload7.PostedFile.ContentLength;

                    getapplicationid();
                    FileUpload7.SaveAs(Server.MapPath("~/poea registration/") + applicationid + ".pdf");

                    poeareg = "poea registration/" + applicationid + ".pdf";
                    poea = true;

                }




                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Upload POEA Registration in PDF Format Only');</script>");
                }

            }

            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }

            if (FileUpload8.HasFile == true)
            {

                String contenttype8 = FileUpload8.PostedFile.ContentType;
               

                if (contenttype8 == "application/pdf")
                {
                    int filesize;
                    filesize = FileUpload8.PostedFile.ContentLength;
                    
                    getapplicationid();
                    FileUpload8.SaveAs(Server.MapPath("~/notarized/") + applicationid + ".pdf");

                    notarized = "notarized/" + applicationid + ".pdf";
                    notary = true;

                }



               

            }





            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Kindly Complete All Attach Requirements');</script>");
            }


            return intent;
            return comprofss;
            return busiper;
            return dti;
            return bir;
            return dole;
            return poea;
            return notary;
        }
        public void getapplicationid()
        {

            String myquery = "select company_id from tb_companyuser";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = myquery;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            if (ds.Tables[0].Rows.Count < 1)
            {
                applicationid = 10001;

            }
            else
            {




                String myquery1 = "select max(company_id) from tb_companyuser";
                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandText = myquery1;
                cmd1.Connection = con;
                SqlDataAdapter da1 = new SqlDataAdapter();
                da1.SelectCommand = cmd1;
                DataSet ds1 = new DataSet();
                da1.Fill(ds1);
                applicationid = Convert.ToInt32(ds1.Tables[0].Rows[0][0].ToString());
                applicationid = applicationid + 1;
                con.Close();
            }

        }
         














 

        public void lettintent()
        {
            if (intent.Text == "")
            {
                notcomp.Visible = true;
                comp.Visible = false;
                FileUpload1.Visible = true;
                Success1.Visible = false;
                btnSave.Visible = true;
                
            }
            else
            {
                notcomp.Visible = false;
                comp.Visible = true;
                FileUpload1.Visible = false;
                Success1.Visible = true;
                btnSave.Visible = false;
                
            }
            
        }

        public void comprofiles()
        {
            if (comprof.Text == "")
            {
                notcomp0.Visible = true;
                comp2.Visible = false;
                FileUpload2.Visible = true;
                Success2.Visible = false;
                btnSave1.Visible = true;

            }
            else
            {
                notcomp0.Visible = false;
                comp2.Visible = true;
                FileUpload2.Visible = false;
                Success2.Visible = true;
                btnSave1.Visible = false;

            }

        }

        public void businesspermits()
        {
            if (businessper.Text == "")
            {
                notcomp1.Visible = true;
                comp3.Visible = false;
                FileUpload3.Visible = true;
                Success3.Visible = false;
                btnSave2.Visible = true;

            }
            else
            {
                notcomp1.Visible = false;
                comp3.Visible = true;
                FileUpload3.Visible = false;
                Success3.Visible = true;
                btnSave2.Visible = false;

            }

        }

        public void dtireq()
        {
            if (dti.Text == "")
            {
                notcomp2.Visible = true;
                comp4.Visible = false;
                FileUpload4.Visible = true;
                Success4.Visible = false;
                btnSave3.Visible = true;

            }
            else
            {
                notcomp2.Visible = false;
                comp4.Visible = true;
                FileUpload4.Visible = false;
                Success4.Visible = true;
                btnSave3.Visible = false;

            }

        }

        public void birreq()
        {
            if (bir.Text == "")
            {
                notcomp3.Visible = true;
                comp5.Visible = false;
                FileUpload5.Visible = true;
                Success5.Visible = false;
                btnSave4.Visible = true;

            }
            else
            {
                notcomp3.Visible = false;
                comp5.Visible = true;
                FileUpload5.Visible = false;
                Success5.Visible = true;
                btnSave4.Visible = false;

            }

        }

        public void dolereq()
        {
            if (dole.Text == "")
            {
                notcomp4.Visible = true;
                comp6.Visible = false;
                FileUpload6.Visible = true;
                Success6.Visible = false;
                btnSave5.Visible = true;

            }
            else
            {
                notcomp4.Visible = false;
                comp6.Visible = true;
                FileUpload6.Visible = false;
                Success6.Visible = true;
                btnSave5.Visible = false;

            }

        }

        public void poeareq()
        {
            if (poea.Text == "")
            {
                notcomp5.Visible = true;
                comp7.Visible = false;
                FileUpload7.Visible = true;
                Success7.Visible = false;
                btnSave6.Visible = true;

            }
            else
            {
                notcomp5.Visible = false;
                comp7.Visible = true;
                FileUpload7.Visible = false;
                Success7.Visible = true;
                btnSave6.Visible = false;

            }

        }

        public void notarizeds()
        {
            if (nota.Text == "")
            {
                notcomp6.Visible = true;
                comp8.Visible = false;
                FileUpload8.Visible = true;
                Success8.Visible = false;
                btnSave7.Visible = true;

            }
            else
            {
                notcomp6.Visible = false;
                comp8.Visible = true;
                FileUpload8.Visible = false;
                Success8.Visible = true;
                btnSave7.Visible = false;

            }

        }
    

        protected void btnSave_Click(object sender, EventArgs e)
        {
            
                submit1();
           
        }

        public void submit1()
        {
            

                if (uploadletter() == true)
                {
                    Random random = new Random();
                    activationcode = random.Next(1001, 9999).ToString();
                    string query = "UPDATE tb_companyuser SET letterofintent = @letterintent   where company_id = @company_id ";
                    SqlCommand cmd2 = new SqlCommand(query, con);
                    cmd2.Parameters.AddWithValue("@company_id", compid.Text);
                    cmd2.Parameters.AddWithValue("@letterintent", intentlink);
                    
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = query;
                    cmd.Connection = con;
                    cmd2.ExecuteNonQuery();
                    Response.Redirect("~/logincompany/complogin.aspx");


                }
            

        }

        public void submit2()
        {


            if (uploadletter() == true)
            {
                Random random = new Random();
                activationcode = random.Next(1001, 9999).ToString();
                string query = "UPDATE tb_companyuser SET companyprofile = @comprofiles   where company_id = @company_id ";
                SqlCommand cmd2 = new SqlCommand(query, con);
                cmd2.Parameters.AddWithValue("@company_id", compid.Text);
                cmd2.Parameters.AddWithValue("@comprofiles", comprofile);

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.Connection = con;
                cmd2.ExecuteNonQuery();
                Response.Redirect("~/logincompany/complogin.aspx");


            }


        }

        public void submit3()
        {


            if (uploadletter() == true)
            {
                Random random = new Random();
                activationcode = random.Next(1001, 9999).ToString();
                string query = "UPDATE tb_companyuser SET businesspermit = @businessper   where company_id = @company_id ";
                SqlCommand cmd2 = new SqlCommand(query, con);
                cmd2.Parameters.AddWithValue("@company_id", compid.Text);
                cmd2.Parameters.AddWithValue("@businessper", businesspermit);

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.Connection = con;
                cmd2.ExecuteNonQuery();
                Response.Redirect("~/logincompany/complogin.aspx");


            }


        }

        public void submit4()
        {


            if (uploadletter() == true)
            {
                Random random = new Random();
                activationcode = random.Next(1001, 9999).ToString();
                string query = "UPDATE tb_companyuser SET dti = @dti   where company_id = @company_id ";
                SqlCommand cmd2 = new SqlCommand(query, con);
                cmd2.Parameters.AddWithValue("@company_id", compid.Text);
                cmd2.Parameters.AddWithValue("@dti", dtireg);

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.Connection = con;
                cmd2.ExecuteNonQuery();
                Response.Redirect("~/logincompany/complogin.aspx");


            }


        }

        public void submit5()
        {


            if (uploadletter() == true)
            {
                Random random = new Random();
                activationcode = random.Next(1001, 9999).ToString();
                string query = "UPDATE tb_companyuser SET bir = @bir   where company_id = @company_id ";
                SqlCommand cmd2 = new SqlCommand(query, con);
                cmd2.Parameters.AddWithValue("@company_id", compid.Text);
                cmd2.Parameters.AddWithValue("@bir", birreg);

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.Connection = con;
                cmd2.ExecuteNonQuery();
                Response.Redirect("~/logincompany/complogin.aspx");


            }


        }

        public void submit6()
        {


            if (uploadletter() == true)
            {
                Random random = new Random();
                activationcode = random.Next(1001, 9999).ToString();
                string query = "UPDATE tb_companyuser SET dole = @dole   where company_id = @company_id ";
                SqlCommand cmd2 = new SqlCommand(query, con);
                cmd2.Parameters.AddWithValue("@company_id", compid.Text);
                cmd2.Parameters.AddWithValue("@dole", dolereg);

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.Connection = con;
                cmd2.ExecuteNonQuery();
                Response.Redirect("~/logincompany/complogin.aspx");


            }


        }

        public void submit7()
        {


            if (uploadletter() == true)
            {
                Random random = new Random();
                activationcode = random.Next(1001, 9999).ToString();
                string query = "UPDATE tb_companyuser SET poea = @poea   where company_id = @company_id ";
                SqlCommand cmd2 = new SqlCommand(query, con);
                cmd2.Parameters.AddWithValue("@company_id", compid.Text);
                cmd2.Parameters.AddWithValue("@poea", poeareg);

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.Connection = con;
                cmd2.ExecuteNonQuery();
                Response.Redirect("~/logincompany/complogin.aspx");


            }


        }

        public void submit8()
        {


            if (uploadletter() == true)
            {
                Random random = new Random();
                activationcode = random.Next(1001, 9999).ToString();
                string query = "UPDATE tb_companyuser SET notarized = @nota where company_id = @company_id ";
                SqlCommand cmd2 = new SqlCommand(query, con);
                cmd2.Parameters.AddWithValue("@company_id", compid.Text);
                cmd2.Parameters.AddWithValue("@nota", notarized);

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = query;
                cmd.Connection = con;
                cmd2.ExecuteNonQuery();
                Response.Redirect("~/logincompany/complogin.aspx");


            }


        }

        protected void btnSave1_Click(object sender, EventArgs e)
        {
            submit2();
        }

        protected void btnSave2_Click(object sender, EventArgs e)
        {
            submit3();
        }

        protected void btnSave3_Click(object sender, EventArgs e)
        {
            submit4();
        }

        protected void btnSave4_Click(object sender, EventArgs e)
        {
            submit5();
        }

        protected void btnSave5_Click(object sender, EventArgs e)
        {
            submit6();
        }

        protected void btnSave6_Click(object sender, EventArgs e)
        {
            submit7();
        }

        protected void btnSave7_Click(object sender, EventArgs e)
        {
            submit8();
        }

       

       

        


       

    }


















    }
