﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PESO3
{
    public partial class apprefrec_form : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected int widesData;
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();
            refrec();
        }
        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }

        public void access()
        {
            if (lblrole.Text == "Admin")
            {

            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }

        public void refrec()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_refer ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvReff.DataSource = dt;
            gvReff.DataBind();
        }
        public void search()
        {
            
            if (ddSearch.Text == "fname")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where fname like '%'+@fname+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("fname", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }
            if (ddSearch.Text == "mname")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where mname like '%'+@mname+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("mname", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }
            if (ddSearch.Text == "lname")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where lname like '%'+@lname+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("lname", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }


        

            if (ddSearch.Text == "skills")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where skills like '%'+@skills+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("skills", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "educ")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where educ like '%'+@educ+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("educ", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "position")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where position like '%'+@position+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("position", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "comp_hname")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where comp_hname like '%'+@comp_hname+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("comp_hname", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "comp_position")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where comp_position like '%'+@comp_position+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("comp_position", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "comp_compname")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where comp_compname like '%'+@comp_compname+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("comp_compname", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "comp_address")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where id like '%'+@comp_address+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("id", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "comp_brgy")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where comp_brgy like '%'+@comp_brgy+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("comp_brgy", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "comp_city")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where comp_city like '%'+@comp_city+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("comp_city", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "comp_district")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where comp_district like '%'+@comp_district+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("comp_district", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

            if (ddSearch.Text == "comp_vacancy")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where comp_vacancy like '%'+@comp_vacancy+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("comp_vacancy", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

        

            


            if (ddSearch.Text == "app_status")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                string sqlquery = "select * from tb_refer where app_status like '%'+@app_status+'%'";
                cmd.CommandText = sqlquery;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("app_status", tbSearch.Text);
                DataTable sdt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(sdt);
                gvReff.DataSource = sdt;
                gvReff.DataBind();

            }

        }
        

        protected void gvReff_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            
        }

        protected void gvReff_RowDataBound1(object sender, GridViewRowEventArgs e)
        {
  
        }

        protected void gvReff_RowDataBound2(object sender, GridViewRowEventArgs e)
        {
            System.Data.DataRowView drv;
            drv = (System.Data.DataRowView)e.Row.DataItem;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (drv != null)
                {
                    String catName = drv[1].ToString();
                    Response.Write(catName + "/");

                    int catNameLen = catName.Length;
                    if (catNameLen > widesData)
                    {
                        widesData = catNameLen;
                        //Row
                        gvReff.Columns[0].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[1].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[2].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[3].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[4].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[5].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[6].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[7].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[8].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[9].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[10].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[11].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[12].ItemStyle.Width = widesData * 50;
                        gvReff.Columns[13].ItemStyle.Width = widesData * 50;
                        
                        
                       
                




                        gvReff.Columns[0].ItemStyle.Wrap = false;
                        gvReff.Columns[1].ItemStyle.Wrap = false;
                        gvReff.Columns[2].ItemStyle.Wrap = false;
                        gvReff.Columns[3].ItemStyle.Wrap = false;
                        gvReff.Columns[4].ItemStyle.Wrap = false;
                        gvReff.Columns[5].ItemStyle.Wrap = false;
                        gvReff.Columns[6].ItemStyle.Wrap = false;
                        gvReff.Columns[7].ItemStyle.Wrap = false;
                        gvReff.Columns[8].ItemStyle.Wrap = false;
                        gvReff.Columns[9].ItemStyle.Wrap = false;
                        gvReff.Columns[10].ItemStyle.Wrap = false;
                        gvReff.Columns[11].ItemStyle.Wrap = false;
                        gvReff.Columns[12].ItemStyle.Wrap = false;
                        gvReff.Columns[13].ItemStyle.Wrap = false;
                        
                        
      
                    



                        //Head
                        gvReff.Columns[0].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[1].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[2].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[3].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[4].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[5].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[6].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[7].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[8].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[9].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[10].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[11].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[12].HeaderStyle.Width = widesData * 50;
                        gvReff.Columns[13].HeaderStyle.Width = widesData * 50;
                        
                        
     
                 




                        gvReff.Columns[0].HeaderStyle.Wrap = false;
                        gvReff.Columns[1].HeaderStyle.Wrap = false;
                        gvReff.Columns[2].HeaderStyle.Wrap = false;
                        gvReff.Columns[3].HeaderStyle.Wrap = false;
                        gvReff.Columns[4].HeaderStyle.Wrap = false;
                        gvReff.Columns[5].HeaderStyle.Wrap = false;
                        gvReff.Columns[6].HeaderStyle.Wrap = false;
                        gvReff.Columns[7].HeaderStyle.Wrap = false;
                        gvReff.Columns[8].HeaderStyle.Wrap = false;
                        gvReff.Columns[9].HeaderStyle.Wrap = false;
                        gvReff.Columns[10].HeaderStyle.Wrap = false;
                        gvReff.Columns[11].HeaderStyle.Wrap = false;
                        gvReff.Columns[12].HeaderStyle.Wrap = false;
                        gvReff.Columns[13].HeaderStyle.Wrap = false;
                        
                        
 
                        

                    }

                }
            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            search();
        }

        protected void gvReff_SelectedIndexChanged(object sender, EventArgs e)
        {

            GridViewRow gr = gvReff.SelectedRow;
            
            //Applicant
            lbfname.Text = gr.Cells[1].Text;
            lbmname.Text = gr.Cells[2].Text;
            lblname.Text = gr.Cells[3].Text;
            lblname.Text = gr.Cells[3].Text;

            //Company
            lbhname.Text = gr.Cells[4].Text;
            lbcposition.Text = gr.Cells[5].Text;
            lbdepartment.Text = gr.Cells[6].Text;
            lbcompname.Text = gr.Cells[7].Text;
            lbcaddress.Text = gr.Cells[8].Text;
            lbcbrgy.Text = gr.Cells[9].Text;
            lbccity.Text = gr.Cells[10].Text;
            lbcdistrict.Text = gr.Cells[9].Text;
            lbvacancy.Text = gr.Cells[12].Text;
            lbdate.Text = gr.Cells[13].Text;
            lbstatus.Text = gr.Cells[14].Text;
        }

        public void referal()
        {
            //date
            Session["date"] = lbdate.Text;

            //head name and address of company
            Session["headname"] = lbhname.Text;
            Session["positon"] = lbcposition.Text;
            Session["dept"] = lbdepartment.Text;
            Session["company"] = lbcompname.Text;
            Session["address"] = lbcaddress.Text;
            Session["barangay"] = lbcbrgy.Text;
            Session["city"] = lbccity.Text;
            Session["district"] = lbcdistrict.Text;


            //Applicant Name,Address,and company Vacancy
            Session["fname"] = lbfname.Text;
            Session["mname"] = lbmname.Text;
            Session["lname"] = lblname.Text;
            Session["vacancy"] = lbvacancy.Text;

            Response.Redirect("sampleprint.aspx");
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            referal();
        }

    }
}