﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Net.Mail;
using System.Net;

namespace PESO3
{
    public partial class applicant_reffered : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected int widesData;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblcompemail.Text = "" + Session["email"];
            lblposition.Text = "" + Session["position"];
            lblhead.Text = "" + Session["head_name"];
            lblcompname.Text = "" + Session["company_name"];
            lbldept.Text = "" + Session["department"];
            address.Text = Session["address"].ToString();
            barangay.Text = Session["brgy"].ToString();
            city.Text = Session["town_city"].ToString();
            district.Text = Session["district"].ToString();


            //fileupdload
            require.Text = "" + Session["requirements"];
            compid.Text = "" + Session["company_id"];
            intent.Text = "" + Session["letterofintent"];
            comprof.Text = "" + Session["companyprofile"];
            businessper.Text = "" + Session["businesspermit"];
            dti.Text = "" + Session["dti"];
            bir.Text = "" + Session["bir"];
            dole.Text = "" + Session["dole"];
            poea.Text = "" + Session["poea"];
            nota.Text = "" + Session["notarized"];





            Session["email"] = lblemail.Text.Trim();
            Session["company_name"] = lblcompname.Text.Trim();
            Session["department"] = lbldept.Text.Trim();
            Session["position"] = lblposition.Text.Trim();
            Session["head_name"] = lblhead.Text.Trim();
            Session["address"] = address.Text.Trim();
            Session["brgy"] = barangay.Text.Trim();
            Session["town_city"] = city.Text.Trim();
            Session["district"] = district.Text.Trim();
            //-------------fileupload
            Session["letterofintent"] = intent.Text.Trim();
            Session["companyprofile"] = comprof.Text.Trim();
            Session["businesspermit"] = businessper.Text.Trim();
            Session["dti"] = dti.Text.Trim();
            Session["bir"] = bir.Text.Trim();
            Session["dole"] = dole.Text.Trim();
            Session["poea"] = poea.Text.Trim();
            Session["notarized"] = nota.Text.Trim();
            Session["company_id"] = compid.Text.Trim();


            applicantref();

            requirecomplete();
        }

        public void requirecomplete()
        {
            if (require.Text == "Not Complete")
            {
                hlreq.Visible = true;
            }
            else if (require.Text == "Complete")
            {
                hlreq.Visible = false;
            }
        }


        public void applicantref()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_refer where  comp_compname='" + lblcompname.Text + "' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvApplicant.DataSource = dt;
            gvApplicant.DataBind();
        }
        private void notify()
        {
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential("caloocanpeso21@gmail.com", "joloairagenachavez");
            smtp.EnableSsl = true;
            MailMessage msg = new MailMessage();
            msg.Subject = "Applicant Status";
            msg.Body = "Applicant " + fname.Text + " " + mname.Text + ", " + lname.Text + " Status is " + ddStatus.Text + "  \nReasons:  \n"+tbremarks.Text+"\nThanks ";
            string toaddress = tbemail.Text;
            string toaddress2 = lblemail.Text;
            msg.To.Add(toaddress);
            msg.To.Add(toaddress2);
            string fromaddress = "caloocanpeso21@gmail.com";
            msg.From = new MailAddress(fromaddress);
            try
            {
                smtp.Send(msg);
            }
            catch
            {
                throw;
            }
        }

        protected void gvApplicant_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void gvApplicant_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = gvApplicant.SelectedRow;
            tbId.Text = gr.Cells[1].Text;
            fname.Text = gr.Cells[2].Text;
            mname.Text = gr.Cells[3].Text;
            lname.Text = gr.Cells[4].Text;
            tbemail.Text = gr.Cells[5].Text;
            ddStatus.Text = gr.Cells[6].Text;
            enable();
        }

        public void clear()
        {
            tbId.Text = "";
            fname.Text = "";
            mname.Text = "";
            lname.Text = "";
            tbemail.Text = "";
            ddStatus.Text = "";
            tbremarks.Text = "";
            disable();

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            updatedata();
        }
        public void updatedata()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {
                string query = "UPDATE tb_refer SET fname = @fname,mname=@mname,lname = @lname,app_status = @status, Remarks = @remarks  where id = @id ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@id", tbId.Text);
                cmd.Parameters.AddWithValue("@fname", fname.Text);
                cmd.Parameters.AddWithValue("@mname", mname.Text);
                cmd.Parameters.AddWithValue("@lname", lname.Text);
                cmd.Parameters.AddWithValue("@status", ddStatus.Text);
                cmd.Parameters.AddWithValue("@remarks", tbremarks.Text);
                



                cmd.Connection.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                    notify();
                    gvApplicant.DataBind();
                    clear();

                    
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);
                }
            }
        }
        public void enable()
        {
            
            fname.Enabled = true;
            mname.Enabled = true;
            lname.Enabled = true;
            tbemail.Enabled = true;
            tbremarks.Enabled = true;
            ddStatus.Enabled = true;
        }
        public void disable()
        {
            tbId.Enabled = false;
            fname.Enabled = false;
            mname.Enabled = false;
            lname.Enabled = false;
            tbemail.Enabled = false;
            tbremarks.Enabled = false;
            ddStatus.Enabled = false;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}