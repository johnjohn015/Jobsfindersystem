﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;

namespace PESO3
{
    public partial class _event : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        DataSet ds = new DataSet();
        SqlCommand com;
        string str;
        SqlCommand coms;
        string strs;
        static String activationcode;
        static String imagelink;
        static Int32 applicationid;
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();
            events();
        }
        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }

        public void access()
        {
            if (lblrole.Text == "Admin")
            {

            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }
        public void events()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_slider ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvEvent.DataSource = dt;
            gvEvent.DataBind();
        }
       


            

        protected void btnSave_Click(object sender, EventArgs e)
        {
            
            
                FileUpload1.SaveAs(Server.MapPath("~/index/") + Path.GetFileName(FileUpload1.FileName));
                String link = "" + Path.GetFileName(FileUpload1.FileName);

                string query = "UPDATE tb_slider SET ImageName = '" + link + "'   where id = '" + tbid.Text + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                Label1.Text = "Data Has Been Saved Succesful";
            
        }

        protected void gvCompAccounts_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = gvEvent.SelectedRow;
            tbid.Text = gr.Cells[1].Text;
        }
        

        
    }
}