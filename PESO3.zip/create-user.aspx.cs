﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace PESO3
{
    public partial class create_user : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected void Page_Load(object sender, EventArgs e)
        {
            lblemail.Text = "Your Email is " + Request.QueryString["emailadd"].ToString() + ", Kindly Check Your Email Inbox For Activation Code";
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            String myquery = "Select * from tb_companyuser where email = '" + Request.QueryString["emailadd"] + "'";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = myquery;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if(ds.Tables[0].Rows.Count>0)
            {
                String activationcode;
                activationcode = ds.Tables[0].Rows[0]["activationcode"].ToString();
                if (activationcode == tbcode.Text)
                {
                    changestatus();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Verified Successfully');</script>");
                    Response.Redirect("~/logincompany/complogin.aspx");
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('You Have Entered Invalid Code, Kindly Check Your Mail Inbox');</script>");
                }
            }
        }
        private void changestatus()
        {
            String updatedata = "Update tb_companyuser set status='activate' where email='" + Request.QueryString["emailadd"]+"'";
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updatedata;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }
    }
}