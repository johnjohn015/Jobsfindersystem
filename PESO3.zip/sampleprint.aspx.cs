﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PESO3
{
    public partial class sampleprint : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            getdata();
        }
        public void getdata()
        {
            //date
            lblDate.Text = Session["date"].ToString();

            //head name and address of company
            lblhead.Text = Session["headname"].ToString();
            lblposition.Text = Session["positon"].ToString();
            lbldept.Text = Session["dept"].ToString();
            lblcompany.Text = Session["company"].ToString();
            lbladdress.Text = Session["address"].ToString();
            lblbrgy.Text = Session["barangay"].ToString();
            lblcity.Text = Session["city"].ToString();
            lbldistrict.Text = Session["district"].ToString();

            //Applicant Name,Address,and company Vacancy
            lblfname.Text = Session["fname"].ToString();
            lblmname.Text = Session["mname"].ToString();
            lbllname.Text = Session["lname"].ToString();
            lblVacancy.Text = Session["vacancy"].ToString();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Apprec_form.aspx");

        }
    }
}