﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PESO3
{
    public partial class Reg_form : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();

            if (!IsPostBack)
            {
                Calendar1.Visible = false;
                ddyear.Visible = false;
                ddmonth.Visible = false;
                lblyear.Visible = false;
                lblmonth.Visible = false;

                DataSet years = new DataSet();
                years.ReadXml(Server.MapPath("~/Year.xml"));

                ddyear.DataTextField = "Number";
                ddyear.DataTextField = "Number";

                ddyear.DataSource = years;
                ddyear.DataBind();

                DataSet months = new DataSet();
                months.ReadXml(Server.MapPath("~/Month.xml"));

                ddmonth.DataTextField = "Name";
                ddmonth.DataTextField = "Number";

                ddmonth.DataSource = months;
                ddmonth.DataBind();
            }
            
        }
        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }

        public void access()
        {
            if (lblrole.Text == "Admin")
            {

            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }

       
        public void clear()
        {
            tbId.Text = "";
            tbfname.Text = "";
            tbmname.Text = "";
            tblname.Text = "";
            tbaddress.Text = "";
            tbbrgy.Text = "";
            tbcity.Text = "";
            tbdistrict.Text = "";
            tbDate.Text = "";
            ddgender.Text = "";
            tbage.Text = "";
            tbeduc.Text = "";
            tbposition.Text = "";
            ddskills.Text = "Others";
            tbcompexp.Text = "";
            tbyear.Text = "";
            tbworkexp.Text = "";
        }

        public void submit()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_applicants values('" + tbposition.Text + "','" + tbfname.Text + "','" + tbmname.Text + "','" + tblname.Text + "','" + tbaddress.Text + "','" + tbbrgy.Text + "','" + tbcity.Text + "','" + tbdistrict.Text + "','" + tbDate.Text + "','" + tbage.Text + "','" + ddgender.Text + "','" + tbeduc.Text + "','" + ddskills.Text + "','" + tbworkexp.Text + "','" + tbcompexp.Text + "','" + tbyear.Text + "','" + tbOthers.Text + "','" + tbemail.Text + "')";
            cmd.ExecuteNonQuery();
            clear();
            con.Close();
            Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Applicant Registered');</script>");


        }
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            int k = CalculateAge(Calendar1.SelectedDate);
            if (k <= 18)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Under Age');</script>");
            }
            else if(tbposition.Text == "" || tbfname.Text == "" || tblname.Text == "" || tbaddress.Text == "" || tbDate.Text == "" || ddgender.Text == "" || tbemail.Text == "" || tbeduc.Text == "" || ddskills.Text == "" || tbworkexp.Text == "" || tbyear.Text == "") 
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Please Fill up Empty Field');</script>");
                val1.Visible = true;
                val2.Visible = true;
                val3.Visible = true;
                val4.Visible = true;
                val5.Visible = true;
                val6.Visible = true;
                val7.Visible = true;
                val8.Visible = true;
                val9.Visible = true;
                val10.Visible = true;
                val11.Visible = true;
                val12.Visible = true;
            }
            else 
            {
                submit();
            }

            
        }
        public static int CalculateAge(DateTime birthdate)
        {
          
            int years = DateTime.Now.Year - birthdate.Year;
           
            if (DateTime.Now.Month < birthdate.Month || (DateTime.Now.Month == birthdate.Month && DateTime.Now.Day < birthdate.Day))
                years--;
            return years;
        }
       

        

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
                ddyear.Visible = false;
                ddmonth.Visible = false;
                lblyear.Visible = false;
                lblmonth.Visible = false;
                
                tbDate.Text = "";
            }
            else
            {
                Calendar1.Visible = true;
                ddyear.Visible = true;
                ddmonth.Visible = true;
                lblyear.Visible = true;
                lblmonth.Visible = true;
            }

                
            
           
        }

        public void dob()
        {
            tbDate.Text = Calendar1.SelectedDate.ToString(" MMMM dd, yyyy");
            Calendar1.Visible = false;
        }

        protected void datebirth_SelectionChanged(object sender, EventArgs e)
        {
            dob();
        }

        protected void ddyear_SelectedIndexChanged(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar1.VisibleDate = new DateTime(year, month, 1);
            Calendar1.SelectedDate = new DateTime(year, month, 1);
        }

        protected void ddmonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            int year = Convert.ToInt16(ddyear.SelectedValue);
            int month = Convert.ToInt16(ddmonth.SelectedValue);

            Calendar1.VisibleDate = new DateTime(year, month, 1);
            Calendar1.SelectedDate = new DateTime(year, month, 1);
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            tbDate.Text = Calendar1.SelectedDate.ToShortDateString();
            tbDate.Text = Calendar1.SelectedDate.ToString(" MMMM dd, yyyy");
            Calendar1.Visible = false;
            ddyear.Visible = false;
            ddmonth.Visible = false;
            lblyear.Visible = false;
            lblmonth.Visible = false;

            DateTime startdate = Calendar1.SelectedDate;
            DateTime enddate = DateTime.Now;
            tbage.Text = CalcAge(enddate, startdate).ToString();

        }

       


        public long CalcAge(System.DateTime StartDate, System.DateTime EndDate)
        {
            long age = 0;
            System.TimeSpan ts = new TimeSpan(StartDate.Ticks - EndDate.Ticks);
            age = (long)(ts.Days / 365);
            return age;
        }

        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {
            if (e.Day.IsOtherMonth)
            {
                e.Day.IsSelectable = false;
                

            }
        }

        protected void ddskills_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddskills.Text == "Others")
            {
                ddskills.Visible = false;
                btnClose.Visible = true;
                tbOthers.Visible = true;
                
            }
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            ddskills.Visible = true;
            btnClose.Visible = false;
            tbOthers.Visible = false;
            
        }
    }
}