﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PESO3
{
    public partial class Dash_form : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;");
        protected int widesData;
        protected void Page_Load(object sender, EventArgs e)
        {
            lbluser();
            access();
            lblusertrans();
            accounts();
            foreach (GridViewRow row in gvAccounts.Rows)
            {

                string pwd = new string('*', row.Cells[8].Text.Length);
                string pwd2 = new string('*', row.Cells[9].Text.Length);

                row.Cells[8].Text = pwd;
                row.Cells[9].Text = pwd2;

            }
        }


        public void lbluser()
        {
            lblrole.Text = "" + Session["role"];
        }
        public void lblusertrans()
        {
            Session["role"] = lblrole.Text.Trim();
        }
       
        public void access()
        {
            if (lblrole.Text == "Admin")
            {
                
            }
            else if (lblrole.Text == "Employee")
            {
                hlDash.Visible = false;
                HyperLink1.Visible = false;
            }
        }
        

        public void accounts()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  tb_users ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvAccounts.DataSource = dt;
            gvAccounts.DataBind();
        }

        protected void gvAccounts_SelectedIndexChanged(object sender, EventArgs e)
        {
            EditButton.Visible = true;
            DeleteButton.Visible = true;

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            EditButton.Visible = false;
            DeleteButton.Visible = false;
        }
        public void clear()
        {
            ddrole.Text = "";
            tbfname.Text = "";
            tbmname.Text = "";
            tblname.Text = "";
            tbemail.Text = "";
            tbusername.Text = "";
            tbpassword.Text = "";
            tbconfirm.Text = "";

        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (ddrole.Text == "" || tbfname.Text == "" || tblname.Text == "" || tbemail.Text == "" || tbusername.Text == "" || tbusername.Text == "" || tbpassword.Text == "" || tbconfirm.Text == "")
           {
               Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Please Fill up Empty Field');</script>");
               val1.Visible = true;
               val2.Visible = true;
               val3.Visible = true;
               val4.Visible = true;
               val5.Visible = true;
               val6.Visible = true;
               val7.Visible = true;
               val8.Visible = true;
           }
            else if (tbpassword.Text != tbconfirm.Text)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Password And Confirm Password not Match');</script>");
            }
            else{
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tb_users values('" + ddrole.Text + "','" + tbfname.Text + "','" + tbmname.Text + "','" + tblname.Text + "','" + tbemail.Text + "','" + tbusername.Text + "','" + tbpassword.Text + "','" + tbconfirm.Text + "','deactive')";
            cmd.ExecuteNonQuery();
               clear();
            con.Close();
            Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Employee Registered');</script>");
           }
           }

        protected void EditButton_Click(object sender, ImageClickEventArgs e)
        {
            updatedata();
        }
        public void updatedata()
        {
            using (SqlConnection sqlConn = new SqlConnection(@"Data Source=SQL5040.site4now.net;Initial Catalog=DB_A4501B_pesocaloocan;User Id=DB_A4501B_pesocaloocan_admin;Password=johndiv02152017;"))
            {

                string query = "UPDATE tb_users SET  role = @role,fname = @fname,mname = @mname,lname = @lname,email = @email,username = @username,password = @password,confirmpass = @confirm,status = @status where userid = @userid ";
                SqlCommand cmd = new SqlCommand(query, sqlConn);
                cmd.Parameters.AddWithValue("@userid", tbId.Text);
                cmd.Parameters.AddWithValue("@role", ddrole.Text);
                cmd.Parameters.AddWithValue("@fname", tbfname.Text);
                cmd.Parameters.AddWithValue("@mname", tbmname.Text);
                cmd.Parameters.AddWithValue("@lname", tblname.Text);
                cmd.Parameters.AddWithValue("@email", tbemail.Text);
                cmd.Parameters.AddWithValue("@username", tbusername.Text);
                cmd.Parameters.AddWithValue("@password", tbpassword.Text);
                cmd.Parameters.AddWithValue("@confirm", tbconfirm.Text);
                cmd.Parameters.AddWithValue("@status", ddstatus.Text);
                


                cmd.Connection.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    gvAccounts.DataBind();
                   
                    clear();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error " + ex.Message);

                }
            }
        }

        protected void DeleteButton_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void gvAccounts_SelectedIndexChanged1(object sender, EventArgs e)
        {
            GridViewRow gr = gvAccounts.SelectedRow;
            tbId.Text = gr.Cells[1].Text;
            ddrole.Text = gr.Cells[2].Text;
            tbfname.Text = gr.Cells[3].Text;
            tbmname.Text = gr.Cells[4].Text;
            tblname.Text = gr.Cells[5].Text;
            tbemail.Text = gr.Cells[6].Text;
            tbusername.Text = gr.Cells[7].Text;
            tbpassword.Text = gr.Cells[8].Text;
            tbconfirm.Text = gr.Cells[9].Text;
            ddstatus.Text = gr.Cells[10].Text;
            EditButton.Visible = true;
            DeleteButton.Visible = true;
            ddstatus.Enabled = true;
            btnSave.Enabled = false;
            btnCancel.Enabled = false;
        }

       
    }
}